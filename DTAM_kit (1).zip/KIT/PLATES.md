# Пластины: все промпты и правила

На каждый клип — **8 пластин** 16:9, которые после кропа становятся 1920×1080.
Промпты писались так, чтобы генератор не отказал (без крови, мяса, оружия)
и не насыпал надписей.

## Общий шаблон промпта

```
Cinematic horror photograph, 16:9 widescreen. <сцена, детали, свет>.
heavy film grain, no people, no text, no letters.
```

Для стилизации под живопись: `Cinematic dark fantasy painting, 16:9 widescreen. …`
Для фигур: `no visible face` вместо `no people`.

## Постобработка (всегда)

```python
from PIL import Image, ImageEnhance
import numpy as np, glob, os
for f in sorted(glob.glob("raw_*.png")):
    n = f[4:-4]
    im = Image.open(f).convert("RGB"); w, h = im.size
    if w/h > 16/9:
        nw = int(h*16/9); im = im.crop(((w-nw)//2, 0, (w-nw)//2+nw, h))
    else:
        nh = int(w*9/16); im = im.crop((0, (h-nh)//2, w, (h-nh)//2+nh))
    im = im.resize((1920, 1080), Image.LANCZOS)
    m = float(np.asarray(im.convert("L")).mean())
    if m < 30:
        im = ImageEnhance.Brightness(im).enhance(min(1.9, 32/max(m, 6)))
    im.save(f"{n}.jpg", quality=88, optimize=True, progressive=True)
    os.remove(f)
```

Контроль: `mean` итоговой jpg 13–40, вес 200–600 КБ.
Готовые пластины кладутся в `code/bgs9|bgs10|bgs11/` — рендер ищет их рядом с собой.

---

## Клип 1 — FOLLOW ME (FNAF 3), фиолетовая камера наблюдения — `plates/bgs9/`

| файл | промпт |
|---|---|
| `stage` | Abandoned pizzeria show stage at night, three bulky animatronic mascot figures on the stage, checkered floor in front, deep purple and red lighting, party hats, dust and cobwebs, heavy film grain, no visible faces, no text, no letters. |
| `party` | Abject birthdayparty room of an abandoned pizzeria, long tables, paper hats, floating balloons in the dark, overturned chairs, deep violet shadows, heavy film grain, no people, no text, no letters. |
| `corridor` | Long empty hallway of an abandoned pizzeria at night, black and white checkered floor, doors along the walls, one flickering ceiling light, deep purple shadow at the end, security camera atmosphere, film grain, no text, no letters, no people. |
| `face` | Extreme close-up of an old vintage animatronic bear mascot head in darkness, cracked plastic casing, blank glassy eye reflecting a single pinpoint of light, dust on the fur, deep violet and red rim light, heavy film grain, no text, no letters, no logos. |
| `vent` | Inside a narrow metal ventilation shaft, dust and cobwebs, faint light at the far end, scratched steel walls, claustrophobic, deep violet darkness, heavy film grain, no text, no letters, no people. |
| `cake` | Forgotten birthday cake with candles on a table in an abandoned pizzeria at night, frosting cracked, dust, balloons floating in the dark behind, deep violet light, sad and eerie, heavy film grain, no text, no letters, no people. |
| `boarded` | Boarded-up window and wall with peeling posters inside an abandoned building, thin shafts of cold light through the gaps, dust, deep violet shadow, heavy film grain, no readable text, no letters, no people. |
| `room` | Wide view of an empty pizzeria dining room at night seen from a corner, rows of tables and chairs, checkered floor, stage in the distance with dark figures, security-camera mood, cold violet light and dust, heavy film grain, no text, no letters, no people. |

---

## Клип 2 — DEAD AGAIN (готический собор, кровь) — `plates/bgs10/`

| файл | промпт |
|---|---|
| `cathedral` | Ancient gothic wooden cathedral with a cross on the roof ridge, standing alone against a blood-red stormy night sky with a thin crimson crescent moon, black tree silhouettes at the edges, mist over the ground, dramatic red rim light, heavy film grain, empty scene with no people, no text, no letters. |
| `nave` | Interior of an abandoned gothic cathedral nave, tall stone columns, pointed arches, rows of long burnt-out candles, red light spilling through a rose window, dust in the air, deep shadows, heavy film grain, no people, no text, no letters. |
| `roof` | View standing on the steep shingled roof of an old gothic church at night, a black iron cross silhouetted against a huge blood-red moon, red clouds streaming past, wind-bent trees far below, vertigo and dread, heavy film grain, no people, no text, no letters. |
| `altar` | Old stone altar inside a ruined chapel, a plain wooden crucifix above it, melted red candles, a heavy iron candelabra, deep red glow, dust and cobwebs, terrifying quiet atmosphere, heavy film grain, no people, no text, no letters. |
| `well` | Ancient stone well in a foggy graveyard at night, crooked gravestones and iron crosses around it, dark water far inside the well, red moonlight through mist, dead grass, dread and emptiness, heavy film grain, no people, no text, no letters. |
| `glass` | Huge gothic stained glass window seen from inside a dark church, abstract red glass panels glowing, cracked leading, light shafts cutting through dust, oppressive red and black palette, heavy film grain, no figures, no readable text, no letters. |
| `hooded` | Tall dark hooded figure standing motionless in a doorway at the end of a stone corridor, face completely hidden in shadow, a single dim red light behind, dust and cold mist, unsettling silhouette, heavy film grain, no visible face, no text, no letters. |
| `storm` | Low angle view of a black gothic cathedral spire against a towering blood-red storm sky, lightning glowing inside the clouds, crows scattering as tiny silhouettes, torrential atmosphere, heavy film grain, no people, no text, no letters. |

---

## Клип 3 — I GOT NO TIME (FNAF 4, фонарик) — `plates/bgs11/`

| файл | промпт |
|---|---|
| `bedroom` | Dark child's bedroom at night, small bed with crumpled blanket, scattered toys on the floor, cold moonlight through a window, almost everything in shadow, deep teal-green darkness, heavy film grain, empty room, no people, no text, no letters. |
| `hall` | Narrow house hallway at night seen from a child's height, wallpaper with faded pattern, two doors, one door slightly ajar with blackness behind it, cold green-blue darkness, dust in the air, heavy film grain, no people, no text, no letters. |
| `closet` | Old closet door open a crack at night, hanging clothes inside, two faint glints of light deep in the darkness of the gap, cold teal shadows, heavy film grain, no people, no text, no letters. |
| `drawings` | Children's crayon drawings taped to a dark bedroom wall, lit by a harsh flashlight beam from the side, the drawings show crude animal mascot figures, long shadows, teal-green darkness beyond the light, dust motes in the beam, heavy film grain, no readable writing, no letters. |
| `doorway` | Tall dark doorway at the end of a room, inside it a huge bulky animatronic mascot silhouette standing completely still, face in total shadow, faint cold light rimming its ears and shoulders, oppressive teal-black palette, heavy film grain, no visible face, no text, no letters. |
| `clock` | Dim bedside table at night with a glowing clock face and a small lamp switched off, tangled blanket edge in the foreground, everything else swallowed by darkness, warm amber glow against cold teal shadow, heavy film grain, no people, no text, no letters. |
| `window` | Child's bedroom window at night, curtains half drawn, cold blue moonlight on the glass, a large indistinct dark shape standing outside beyond the glass, condensation, teal-black palette, heavy film grain, no visible face, no text, no letters. |
| `stage` | Abandoned pizzeria show stage in total darkness, three bulky animatronic mascot silhouettes on the stage barely catching cold green light, party hats and a toppled microphone stand in front, dust and cobwebs, heavy film grain, no visible faces, no text, no letters. |

---

## Чего не делать

- Не просить «blood splatter on tiles», «corpse», «gore», «knife» — отказ модерации.
- Не просить «text on the wall», «poster with words», «sign» — генератор насыплет
  псевдо-букв, это выглядит как брак.
- Не генерировать 1:1 — только 16:9, иначе кроп съест композицию.
- Не оставлять пластину темнее mean 13 — на видео будет чёрный квадрат.
