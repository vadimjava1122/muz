# Быстрый старт

Кит самодостаточный: код + шрифты + пластины + лирика + аудио. Готовые mp4 в архив
не входят (лимит 25 МБ) — вместо них превью-кадры `clips_preview.jpg`.

```bash
pip install -r requirements.txt
cd code    # шрифты лежат в code/fonts, пластины в code/bgs*
python3 render3.py --project ../projects/notime.json --start 0 --end 56.45 \
        --out /tmp/master.mp4 --crf 21        # минута клипа ≈ 7–9 минут на 2 ядрах
ffmpeg -y -i /tmp/master.mp4 -c:v libx264 -preset slow -crf 26 -threads 2 \
  -x264-params rc-lookahead=10:bframes=3:ref=3 -pix_fmt yuv420p \
  -c:a aac -b:a 192k -movflags +faststart out.mp4
```

| файл | что внутри |
|---|---|
| `INSTRUCTION.md` | **главное**: весь процесс по шагам, ключи движка, грабли, чек-лист |
| `AGENT_PROMPT.md` | готовый промпт для другого ИИ (копируй целиком) |
| `PLATES.md` | промпты всех 24 пластин + скрипт постобработки |
| `runbook.sh` | прогон одного клипа одной командой |
| `code/` | движок рендера + анализ музыки + пластины `bgs9/bgs10/bgs11` |
| `lyrics/*/` | таблицы строк EN/RU + генератор json/srt (копируй и меняй таблицу) |
| `projects/` | пресеты трёх стилей |
