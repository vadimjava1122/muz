"""I GOT NO TIME — The Living Tombstone (FNAF 4). Клип 0:00–0:56.45, EN + RU.

Источник — присланный mp4 (56.45 с). Трек опознан по горячим субтитрам в самом видео:
The Living Tombstone — «I Got No Time» (FNAF 4). Официальный текст сверен по
lyrics.com / lyricsondemand / wattpad-копиям (совпадают).
Тайминги сняты с караоке-субтитров исходника: кадры каждые 0.5 с, читались вручную,
поэтому каждая строка привязана к реальному появлению текста.
Окно — от начала файла до конца: 0.0–56.45, включая инструментальный аутро 45.3–56.4
(под него идёт финальная плашка).
"""
import json, re

DUR = 56.45

# (секция, EN, начало, конец, RU)
LINES = [
    ("URGE", "I HAVE THIS URGE, I HAVE THIS URGE TO *KILL", 2.90, 4.35,
     "У меня есть этот порыв, этот порыв убивать"),
    ("URGE", "I HAVE THIS URGE TO *KILL AND SHOW THAT I'M *ALIVE", 4.35, 7.30,
     "Порыв убивать — и показать, что я жив"),
    ("URGE", "I'M GETTING SICK FROM THESE APOLOGIES", 7.30, 9.20,
     "Меня тошнит от этих извинений"),
    ("URGE", "FROM PEOPLE WITH PRIORITIES", 9.20, 10.60,
     "От людей со своими приоритетами"),
    ("URGE", "THAT THEIR LIFE MATTERS SO MUCH MORE THAN MINE", 10.60, 13.40,
     "Что их жизнь важнее моей во много раз"),
    ("URGE", "BUT I'M *STUTTERING, I'M *STUTTERING AGAIN", 13.40, 15.50,
     "Но я заикаюсь, я снова заикаюсь"),
    ("URGE", "NO ONE WILL LISTEN, AND NO ONE WILL UNDERSTAND", 15.50, 18.20,
     "Никто не услышит, и никто не поймёт"),
    ("URGE", "BECAUSE I'M CRYING AS MUCH AS I SPEAK", 18.20, 20.40,
     "Ведь я плачу так же, как говорю"),
    ("URGE", "'CAUSE NO ONE LIKES ME WHEN I *SHRIEK", 20.40, 21.55,
     "Ведь меня не любят, когда я кричу"),
    ("URGE", "WANT TO GO BACK TO WHEN IT ALL BEGAN", 21.55, 24.00,
     "Хочу вернуться туда, где всё началось"),

    ("AWAKE", "SO MY *FLASHLIGHT'S ON, AND STAY UP 'TIL DAWN", 24.00, 26.85,
     "Так что фонарик включён — и не сплю до рассвета"),
    ("AWAKE", "I GOT THIS HEADACHE AND MY LIFE'S ON THE LINE", 26.85, 29.50,
     "У меня эта головная боль, и моя жизнь на кону"),
    ("AWAKE", "I FELT LIKE I WON, BUT I WASN'T DONE", 29.50, 31.85,
     "Я думал, что победил, но я ещё не закончил"),
    ("AWAKE", "THE *NIGHTMARE REPEATS ITSELF EVERY TIME", 31.85, 34.30,
     "Кошмар повторяется каждый раз"),
    ("AWAKE", "GOT TO KEEP MY CALM, AND CARRY ON", 34.30, 37.30,
     "Надо держать себя в руках и идти дальше"),
    ("AWAKE", "STAY AWAKE UNTIL THE SUN WILL SHINE", 37.30, 40.00,
     "Не спать, пока не взойдёт солнце"),
    ("AWAKE", "BUT I'M NOT SO *STRONG, AND THEY'RE NOT GONE", 40.00, 42.20,
     "Но я не так силён, а они не ушли"),
    ("AWAKE", "THEY'RE STILL OUT THERE TO TAKE WHAT'S LEFT OF MINE", 42.20, 45.30,
     "Они всё ещё там — забрать то, что от меня осталось"),
]


def syll(w):
    return max(1, len(re.findall(r"[aeiouy]+", w.lower())))


lines = []
for i, (sec, txt, st, en, ru) in enumerate(LINES):
    ws = [(raw.lstrip("*"), raw.startswith("*")) for raw in txt.split()]
    tot = sum(syll(x) for x, _ in ws)
    span = max(0.25, (en - st) - 0.05)
    t = st
    wl = []
    for word, hot in ws:
        d = span * syll(word) / tot
        wl.append({"w": word, "start": round(t, 3), "end": round(t + d, 3), "hot": hot})
        t += d
    nxt = LINES[i + 1][2] if i + 1 < len(LINES) else en
    lines.append({"index": i, "section": sec, "text": " ".join(w for w, _ in ws), "ru": ru,
                  "start": round(st, 3), "end": round(min(nxt, en + 0.35), 3), "words": wl})

lines[-1]["end"] = 45.35

data = {
    "title": "I GOT NO TIME",
    "artist": "The Living Tombstone",
    "duration": DUR,
    "explicit": False,
    "audio": "../audio/NO_TIME.mp3",
    "notes": ("The Living Tombstone — I Got No Time (FNAF 4). Окно 0:00–56.45 по "
              "присланному файлу. Стиль: фонарик в темноте, спальня и коридоры, "
              "силуэты в дверях, скрим-кадры на битах, капс в Montserrat.")
    ,
    "lines": lines,
    "sections": [
        {"name": "URGE", "start": 0.0, "end": 24.0, "lines": list(range(0, 10))},
        {"name": "AWAKE", "start": 24.0, "end": DUR, "lines": list(range(10, 18))},
    ],
}
json.dump(data, open("lyrics_NO_TIME.json", "w"), ensure_ascii=False, indent=1)


def ts(t, sep=","):
    h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms == 1000:
        s += 1; ms = 0
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


with open("NO_TIME.srt", "w", encoding="utf-8") as f:
    for k, l in enumerate(lines, 1):
        f.write(f"{k}\n{ts(l['start'])} --> {ts(l['end'])}\n{l['text']}\n{l['ru']}\n\n")

print("lines:", len(lines), "dur:", DUR)
