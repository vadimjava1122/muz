"""DEAD AGAIN — asteria (ASTERIA VOL. 1, 2025). Клип 1:00–конец (65.7 с), EN + RU.

Текст официальный (Genius / Musixmatch / Shazam, совпадают), перевод построчный наш.
Окно 60.0–125.66 с: бридж «blood body» → «ten lives in the well» → второй куплет →
финальный хук со стуком «ten, ten, t-t-t-t-ten» и фейд. Границы фраз — по ASR
(faster-whisper, окна 6 с, word_timestamps) и по RMS-структуре трека.
Все времена в файле — ОТНОСИТЕЛЬНО начала клипа (t - 60.0).
"""
import json, re

OFF = 60.0              # начало клипа в исходнике
DUR = 125.66 - OFF      # 65.66 с

# (секция, EN, начало_абс, конец_абс, RU)
LINES = [
    ("BRIDGE", "I'm nobody, I am just a *blood body", 60.00, 66.40,
     "Я никто, я просто тело из крови"),
    ("BRIDGE", "*Ten lives in the well, *dead again", 66.40, 70.90,
     "Десять жизней в колодце — снова мёртв"),
    ("BRIDGE", "*Ten lives in the well, *dead again", 70.90, 75.50,
     "Десять жизней в колодце — снова мёртв"),
    ("BRIDGE", "*Ten lives in the well, *dead again", 75.50, 80.00,
     "Десять жизней в колодце — снова мёртв"),

    ("VERSE", "I can't control my brain", 80.00, 83.30,
     "Я не властен над своим мозгом"),
    ("VERSE", "Can't recognize my ways", 83.30, 86.60,
     "Не узнаю своих собственных путей"),
    ("VERSE", "Over and over again I die inside my dreams, yeah", 86.60, 91.00,
     "Снова и снова я умираю в своих снах"),
    ("VERSE", "Don't know if I hate myself or someone else", 91.00, 95.00,
     "Не знаю, ненавижу ли я себя или кого-то ещё"),
    ("VERSE", "Every future's just a past that'll go to *hell", 95.00, 99.50,
     "Каждое будущее — лишь прошлое, что уйдёт в ад"),
    ("VERSE", "You just know my name, not nothing else", 99.50, 103.00,
     "Ты знаешь только моё имя — и больше ничего"),
    ("VERSE", "I'm a *blood body, bitch, *ten lives in the well", 103.00, 107.50,
     "Я тело из крови, сука, десять жизней в колодце"),

    ("HOOK", "*Ten lives in the well, *dead again", 107.50, 111.50,
     "Десять жизней в колодце — снова мёртв"),
    ("HOOK", "*Ten lives in the well, *dead again", 111.50, 115.50,
     "Десять жизней в колодце — снова мёртв"),
    ("HOOK", "Ten, ten, t-t-t-t-ten, *dead again", 115.50, 119.00,
     "Десять, десять, д-д-д-д-десять, снова мёртв"),
    ("HOOK", "Ten, ten, t-t-t-t-ten, *dead again", 119.00, 124.60,
     "Десять, десять, д-д-д-д-десять, снова мёртв"),
]


def syll(w):
    return max(1, len(re.findall(r"[aeiouy]+", w.lower())))


lines = []
for i, (sec, txt, st, en, ru) in enumerate(LINES):
    ws = [(raw.lstrip("*"), raw.startswith("*")) for raw in txt.split()]
    tot = sum(syll(x) for x, _ in ws)
    span = max(0.25, (en - st) - 0.06)
    t = st
    wl = []
    for word, hot in ws:
        d = span * syll(word) / tot
        wl.append({"w": word, "start": round(t - OFF, 3), "end": round(t - OFF + d, 3), "hot": hot})
        t += d
    nxt = LINES[i + 1][2] if i + 1 < len(LINES) else en
    lines.append({"index": i, "section": sec, "text": " ".join(w for w, _ in ws), "ru": ru,
                  "start": round(st - OFF, 3),
                  "end": round(min(nxt - OFF, en - OFF + 0.4), 3), "words": wl})

lines[-1]["end"] = round(DUR - 0.2, 3)

data = {
    "title": "DEAD AGAIN",
    "artist": "asteria",
    "duration": DUR,
    "explicit": True,
    "audio": "../audio/DEADAGAIN.mp3",
    "notes": ("asteria — DEAD AGAIN, ASTERIA VOL. 1 (20.08.2025). Окно 1:00–2:05.66. "
              "Текст официальный, перевод наш. Готический собор, кровавая луна, крыша, "
              "колодец, стёкла: кровь и ужас без мяса."),
    "lines": lines,
    "sections": [
        {"name": "BRIDGE", "start": 0.0, "end": 20.0, "lines": list(range(0, 4))},
        {"name": "VERSE", "start": 20.0, "end": 47.5, "lines": list(range(4, 11))},
        {"name": "HOOK", "start": 47.5, "end": DUR, "lines": list(range(11, 15))},
    ],
}
json.dump(data, open("lyrics_DEADAGAIN.json", "w"), ensure_ascii=False, indent=1)


def ts(t, sep=","):
    h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms == 1000:
        s += 1; ms = 0
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


with open("DEADAGAIN.srt", "w", encoding="utf-8") as f:
    for k, l in enumerate(lines, 1):
        f.write(f"{k}\n{ts(l['start'])} --> {ts(l['end'])}\n{l['text']}\n{l['ru']}\n\n")

print("lines:", len(lines), "dur:", round(DUR, 2))
