"""FOLLOW ME — TryHardNinja (Five Nights at Freddy's 3 song). Клип 0:00–0:52, EN + RU.

Текст официальный (lyrics.com / sublyric, автор TryHardNinja), перевод построчный наш.
Границы строк — по словам из ASR (faster-whisper small, word_timestamps на 0–24 с) и по
сегментам до 47 с. Окно 0:00–0:52: интро, куплет («over 30 years ago…») и припев с
повтором; дальше в исходнике идёт «Thanks for watching», поэтому клип обрывается на 52 с.
"""
import json, re

DUR = 52.0
LINES = [
    ("Intro", "He's been waiting, abandoned and patient, so long",   1.04, 5.90,
     "Он ждёт — брошенный и терпеливый, так долго"),
    ("Intro", "A savage masked ghost story from the past, he roams", 6.26, 13.10,
     "Дикая история с маской-призраком из прошлого — он бродит"),
    ("Intro", "He said follow me",                                   14.52, 18.00,
     "Он сказал: иди за мной"),
    ("Intro", "Follow, follow, follow",                              18.00, 23.30,
     "Иди, иди, иди"),

    ("Verse", "Over 30 years ago",                                   23.46, 25.50,
     "Больше тридцати лет назад"),
    ("Verse", "When he took them down below",                        25.50, 27.30,
     "Когда он забрал их вниз"),
    ("Verse", "And tonight he walks again",                          27.30, 29.20,
     "И сегодня ночью он снова ходит"),
    ("Verse", "So step inside, enjoy the show",                      29.20, 31.30,
     "Так заходи, наслаждайся шоу"),

    ("Chorus", "*Follow me, then you'll see",                         31.30, 34.20,
     "Иди за мной, тогда увидишь"),
    ("Chorus", "Follow, follow, follow, follow",                      34.20, 36.20,
     "Иди, иди, иди, иди"),
    ("Chorus", "But the truth is hard to swallow",                    36.20, 38.30,
     "Но правду трудно проглотить"),
    ("Chorus", "Follow, follow me",                                   38.30, 40.30,
     "Иди, иди за мной"),
    ("Chorus", "See a *nightmare in action",                          40.30, 42.60,
     "Увидишь кошмар вживую"),
    ("Chorus", "Follow, follow, follow, follow",                      42.60, 44.70,
     "Иди, иди, иди, иди"),
    ("Chorus", "Follow me, see a *nightmare in action",               44.70, 47.60,
     "Иди за мной — увидишь кошмар вживую"),
]


def syll(w):
    return max(1, len(re.findall(r"[aeiouy]+", w.lower())))


lines = []
for i, (sec, txt, st, en, ru) in enumerate(LINES):
    ws = [(raw.lstrip("*"), raw.startswith("*")) for raw in txt.split()]
    tot = sum(syll(x) for x, _ in ws)
    span = max(0.25, (en - st) - 0.06)
    t = st
    wl = []
    for word, hot in ws:
        d = span * syll(word) / tot
        wl.append({"w": word, "start": round(t, 3), "end": round(t + d, 3), "hot": hot})
        t += d
    nxt = LINES[i + 1][2] if i + 1 < len(LINES) else DUR - 0.2
    lines.append({"index": i, "section": sec, "text": " ".join(w for w, _ in ws), "ru": ru,
                  "start": round(st, 3), "end": round(min(nxt, en + 0.4), 3), "words": wl})

lines[-1]["end"] = round(DUR - 0.2, 3)

data = {
    "title": "FOLLOW ME",
    "artist": "TryHardNinja",
    "duration": DUR,
    "explicit": False,
    "audio": "../audio/FOLLOWME.mp3",
    "notes": ("Клип 0:00–0:52 из эдита 001.mp4 (FNAF 3 song «Follow Me», TryHardNinja). "
              "Текст официальный, перевод построчный наш. Визуал — «камера наблюдения» "
              "в заброшенной пиццерии: HUD CAM/REC/NIGHT, сканлайны, статика."),
    "lines": lines,
    "sections": [
        {"name": "Intro", "start": 1.04, "end": 23.46, "lines": list(range(0, 4))},
        {"name": "Verse", "start": 23.46, "end": 31.30, "lines": list(range(4, 8))},
        {"name": "Chorus", "start": 31.30, "end": DUR, "lines": list(range(8, 15))},
    ],
}
json.dump(data, open("lyrics_FOLLOWME.json", "w"), ensure_ascii=False, indent=1)


def ts(t, sep=","):
    h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60)
    ms = int(round((t - int(t)) * 1000))
    if ms == 1000:
        s += 1; ms = 0
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}"


with open("FOLLOWME.srt", "w", encoding="utf-8") as f:
    for k, l in enumerate(lines, 1):
        f.write(f"{k}\n{ts(l['start'])} --> {ts(l['end'])}\n{l['text']}\n{l['ru']}\n\n")

print("lines:", len(lines))
