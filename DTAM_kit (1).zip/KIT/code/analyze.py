#!/usr/bin/env python3
"""Считает энергетику (rms/low/mid/high @30fps) и сетку битов для любого трека.

  python3 analyze.py --audio ../audio/FBM.mp3 --out ../data/fbm
"""
import argparse, json, os, wave, subprocess, sys
import numpy as np

FFMPEG = "/home/user/ffmpeg"
if not os.path.exists(FFMPEG):
    import imageio_ffmpeg
    FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()


def to_wav(src, dst, sr=44100):
    subprocess.run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", src,
                    "-ac", "1", "-ar", str(sr), "-c:a", "pcm_s16le", dst], check=True)
    return dst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--audio", required=True)
    ap.add_argument("--out", required=True, help="префикс для json (без расширения)")
    a = ap.parse_args()
    wav = to_wav(a.audio, "/tmp/_an.wav")
    w = wave.open(wav)
    sr = w.getframerate()
    x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    fps = 30
    hop = sr // fps
    n = len(x) // hop
    frames = x[:n * hop].reshape(n, hop)
    rms = np.sqrt((frames ** 2).mean(1))
    win = 2048
    sw = np.lib.stride_tricks.sliding_window_view(x, win)[::hop][:n]
    S = np.abs(np.fft.rfft(sw * np.hanning(win), axis=1))
    f = np.fft.rfftfreq(win, 1 / sr)

    def band(lo, hi):
        m = (f >= lo) & (f < hi)
        return S[:, m].sum(1)

    low, mid, high = band(20, 200), band(200, 2000), band(2000, 8000)

    def norm(v, k=3):
        v = np.convolve(v, np.ones(k) / k, mode="same")
        return np.clip(v / (np.percentile(v, 99) + 1e-9), 0, 1.5).round(3).tolist()

    json.dump({"fps": fps, "frames": int(n), "rms": norm(rms), "low": norm(low),
               "mid": norm(mid), "high": norm(high)}, open(a.out + "_energy.json", "w"))

    try:
        import librosa
        y, _ = librosa.load(a.audio, sr=22050, mono=True)
        tempo, beats = librosa.beat.beat_track(y=y, sr=22050, units="time")
        json.dump({"tempo": float(np.atleast_1d(tempo)[0]),
                   "beats": [round(float(b), 3) for b in beats]}, open(a.out + "_beats.json", "w"), indent=1)
        print("bpm", float(np.atleast_1d(tempo)[0]), "beats", len(beats))
    except Exception as e:
        dur = len(x) / sr
        step = 60 / 140
        json.dump({"tempo": 140.0, "beats": [round(i * step, 3) for i in range(int(dur / step))]},
                  open(a.out + "_beats.json", "w"), indent=1)
        print("librosa недоступна, биты по сетке 140 bpm", e)


if __name__ == "__main__":
    main()
