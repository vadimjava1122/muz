#!/usr/bin/env python3
"""
PRO-рендер клипа D.T.A.M.: сгенерированные фоны + Ken Burns + смена планов по секциям
+ световые проходы, боке, пульс по битам.

  python3 render2.py --start 23.6 --end 38.3 --out /tmp/test.mp4
  python3 render2.py --end 147.2 --out /tmp/full.mp4
"""
import argparse, json, os, subprocess, sys, math
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import render as R      # раскладка текста, шрифты, спрайты строк, ffmpeg, energy

D, ROOT, LYR, ENER = R.D, R.ROOT, R.LYR, R.ENER
SEC_COLOR = R.SEC_COLOR

BGS = {"Intro": "intro.jpg", "Chorus": "chorus.jpg", "Verse": "verse.jpg",
       "Interlude": "interlude.jpg", "Post-Chorus": "postchorus.jpg", "Outro": "outro.jpg"}
# яркость, подмес цвета, скорость/размах Ken Burns, сила акцентов
MOOD = {
    "Intro":       (0.80, (55, 18, 85), 0.10, 0.85),
    "Chorus":      (0.94, (80, 18, 62), 0.16, 1.25),
    "Verse":       (0.82, (35, 26, 88), 0.09, 0.95),
    "Interlude":   (0.58, (70, 40, 90), 0.07, 1.05),
    "Post-Chorus": (0.92, (82, 18, 55), 0.18, 1.35),
    "Outro":       (0.78, (88, 62, 26), 0.10, 1.10),
}


class ProRenderer(R.Renderer):
    def __init__(self, W, H):
        super().__init__(W, H, style="neon")     # style="neon" → белый текст со свечением
        self.pro = True
        self.f_title = R.font("Montserrat-Bold.ttf", int(24 * self.s))
        self.lw, self.lh = W // 4, H // 4
        yy, xx = np.mgrid[0:self.lh, 0:self.lw].astype(np.float32)
        self.sx, self.sy = xx / self.lw, yy / self.lh

        # ---- «запечённый» грейд каждого фона: яркость, подмес, скрим под текст, виньетка
        self.graded = {}
        for name, fn in BGS.items():
            im = Image.open(os.path.join(D, "bgs", fn)).convert("RGB").resize((W, H), Image.LANCZOS)
            bright, tint, _, _ = MOOD[name]
            a = np.asarray(im, dtype=np.float32) * bright + np.array(tint, dtype=np.float32) * 0.12
            yv = (np.arange(H, dtype=np.float32) / H)[:, None]
            xv = (np.arange(W, dtype=np.float32) / W)[None, :]
            vig = 1.0 - 0.42 * (((xv - 0.5) ** 2 + (yv - 0.5) ** 2) / 0.5)
            scr = 1.0 - 0.48 * np.exp(-(((yv - 0.5) / 0.34) ** 2))
            a = a * np.clip(vig, 0.42, 1.0)[..., None] * scr[..., None]
            self.graded[name] = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))
        # кэш секций по имени
        self.secs = {}
        for s in LYR["sections"]:
            self.secs.setdefault(s["name"], []).append(s)
        self.order = LYR["sections"]

    # ---------- Ken Burns по запечённой плите ----------
    def kenburns(self, name, t, pulse, sec):
        _, _, kb, _ = MOOD[name]
        dur = max(0.1, sec["end"] - sec["start"])
        u = min(1.0, max(0.0, (t - sec["start"]) / dur))
        z = 1.03 + 0.10 * kb * (0.5 - 0.5 * math.cos(u * math.pi * 2)) + 0.020 * pulse
        cx = 0.5 + 0.045 * math.sin(t * 0.19 + len(name))
        cy = 0.5 + 0.035 * math.cos(t * 0.15 + len(name) * 2)
        W, H = self.W, self.H
        w, h = W / z, H / z
        x0 = min(max(0.0, cx * W - w / 2), W - w)
        y0 = min(max(0.0, cy * H - h / 2), H - h)
        return self.graded[name].crop((int(x0), int(y0), int(x0 + w), int(y0 + h))).resize((W, H), Image.BILINEAR)

    # ---------- световой слой в низком разрешении ----------
    def live(self, t, rms, low, high, pulse, col, amp):
        acc = np.zeros((self.lh, self.lw, 3), dtype=np.float32)
        sx, sy = self.sx, self.sy
        cc = [np.array((255, 214, 242), np.float32), np.array((186, 246, 255), np.float32),
              np.array((255, 238, 196), np.float32)]
        for k in range(len(self.part["x"])):
            px = self.part["x"][k] + 0.05 * math.sin(t * self.part["sp"][k] * 2.0 + self.part["ph"][k])
            py = (self.part["y"][k] - 0.030 * t * self.part["sp"][k]) % 1.0
            pr = self.part["r"][k] * (1.0 + 0.7 * high) / 0.35
            g = np.exp(-(((sx - px) * 4.5 / pr) ** 2 + ((sy - py) * 4.5 / pr) ** 2) * 2.0)
            acc += g[..., None] * cc[self.part["c"][k]] / 255.0 * (0.10 + 0.20 * pulse) * amp
        # дыхание цвета снизу
        g = np.exp(-(((sx - 0.5) / 0.55) ** 2 + ((sy - 1.02) / 0.32) ** 2) * 2.0)
        acc += g[..., None] * np.array(col, np.float32) / 255.0 * (0.20 + 0.40 * pulse) * amp
        # диагональный проход света
        sweep = (t * 0.11) % 1.7 - 0.35
        band = np.exp(-((sx + 0.30 * sy - sweep) / 0.055) ** 2)
        acc += band[..., None] * np.array((255, 248, 255), np.float32) / 255.0 * (0.06 + 0.10 * high) * amp
        a8 = np.clip(acc * 255.0, 0, 255).astype(np.uint8)
        return Image.fromarray(a8).resize((self.W, self.H), Image.BILINEAR)

    def frame(self, t):
        W, H, s = self.W, self.H, self.s
        fi = min(len(ENER["rms"]) - 1, max(0, int(t * ENER["fps"])))
        rms, low, high = ENER["rms"][fi], ENER["low"][fi], ENER["high"][fi]
        sec = self.order[0]
        for sn in self.order:
            if sn["start"] <= t < sn["end"]:
                sec = sn
        col = SEC_COLOR.get(sec["name"], (255, 255, 255))
        bi = np.searchsorted(self.beats, t) - 1
        pulse = math.exp(-(t - self.beats[bi]) * 5.5) if 0 <= bi < len(self.beats) else 0.0
        _, _, _, amp = MOOD[sec["name"]]

        plate = self.kenburns(sec["name"], t, pulse, sec)
        prev = None
        for sn in self.order:
            if sn["end"] <= sec["start"] + 0.02:
                prev = sn
        if prev is not None and prev["name"] != sec["name"] and (t - sec["start"]) < 1.0:
            k = (t - sec["start"]) / 1.0
            pim = self.kenburns(prev["name"], min(t, prev["end"] - 0.02), pulse, prev)
            plate = Image.blend(pim, plate, k ** 0.8)

        plate = ImageEnhance.Brightness(plate).enhance(0.96 + 0.10 * pulse + 0.03 * low)
        img = ImageChops.add(plate, self.live(t, rms, low, high, pulse, col, amp)).convert("RGBA")

        # ---------- текст ----------
        li = -1
        for i, l in enumerate(LYR["lines"]):
            if l["start"] <= t < l["end"]:
                li = i
                break
        if li >= 0:
            sprite, boxes = self.line_sprite(li)
            l = LYR["lines"][li]
            k = min(1.0, (t - l["start"]) / 0.28)
            ease = 1 - (1 - k) ** 3
            alpha = int(255 * ease)
            dy = int((1 - ease) * 30 * s)
            sp = sprite
            if k < 1.0:
                sc = 1.0 + 0.06 * (1 - ease)
                sp = sp.resize((int(W * sc), int(H * sc)), Image.BILINEAR)
                dy -= int((sp.size[1] - H) / 2)
            if alpha < 255 or dy:
                sp = sp.copy()
                sp.putalpha(sp.split()[3].point(lambda v: int(v * alpha / 255)))
            img.alpha_composite(sp, (0, dy))
            words = l["words"]
            act = next((wi for wi, w in enumerate(words) if w["start"] <= t < w["end"]), -1)
            if 0 <= act < len(boxes):
                d2 = ImageDraw.Draw(img)
                _, x, y, wd = boxes[act]
                yy2 = y + dy
                d2.text((x, yy2), words[act]["w"], font=self.line_font[li], fill=col + (255,))
                uy = yy2 + int(self.line_lh[li] * 0.92)
                d2.line([x, uy, x + wd, uy], fill=col + (235,), width=max(2, int(5 * s)))
            if li + 1 < len(LYR["lines"]):
                nxt = LYR["lines"][li + 1]["text"]
                if self.f_xs.getlength(nxt) < W * 0.8:
                    ImageDraw.Draw(img).text((W // 2, int(H * 0.76)), nxt, font=self.f_xs,
                                             fill=(255, 255, 255, int(80 + 45 * high)), anchor="mm")

        # вспышка на входе в секцию
        pl = t - sec["start"]
        if 0 <= pl < 0.45:
            fa = int(120 * max(0.0, 1 - pl / 0.45) ** 2)
            fl = Image.new("RGBA", (W, H), col + (fa,))
            img.alpha_composite(fl.filter(ImageFilter.GaussianBlur(26 * s)))

        # ---------- шапка / подвал ----------
        d = ImageDraw.Draw(img)
        d.text((int(72 * s), int(58 * s)), "D.T.A.M.", font=self.f_sm, fill=(255, 255, 255, 220))
        d.text((W - int(72 * s), int(62 * s)), "BRITNEY MANSON", font=self.f_xs,
               fill=(238, 232, 248, 180), anchor="ra")
        # плашка под меткой секции
        lbl = sec["name"].upper()
        lw_ = self.f_sm.getlength(lbl)
        bx, by = W // 2, H - int(96 * s)
        pill = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(pill).rounded_rectangle(
            [bx - lw_ / 2 - 18 * s, by - 17 * s, bx + lw_ / 2 + 18 * s, by + 17 * s],
            radius=int(17 * s), fill=(8, 6, 14, 120))
        img.alpha_composite(pill)
        d = ImageDraw.Draw(img)
        d.text((bx, by), lbl, font=self.f_sm, fill=col + (235,), anchor="mm")
        py = H - int(38 * s)
        d.line([int(72 * s), py, W - int(72 * s), py], fill=(255, 255, 255, 50), width=max(2, int(4 * s)))
        pr = t / LYR["duration"]
        d.line([int(72 * s), py, int(72 * s + (W - 144 * s) * pr), py], fill=col + (240,), width=max(2, int(4 * s)))

        g = self.grain[int(t * 12) % len(self.grain)]
        return Image.blend(img.convert("RGB"), g, 0.055)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=LYR["duration"])
    ap.add_argument("--out", default="/tmp/pro.mp4")
    ap.add_argument("--w", type=int, default=1920)
    ap.add_argument("--h", type=int, default=1080)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--crf", type=int, default=20)
    ap.add_argument("--preset", default="veryfast")
    ap.add_argument("--threads", type=int, default=2)
    a = ap.parse_args()

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    r = ProRenderer(a.w, a.h)
    n = int((a.end - a.start) * a.fps)
    cmd = [R.FFMPEG, "-hide_banner", "-loglevel", "error", "-y",
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{a.w}x{a.h}", "-r", str(a.fps), "-i", "-",
           "-ss", str(a.start), "-t", str(a.end - a.start), "-i", R.ensure_wav(),
           "-map", "0:v", "-map", "1:a",
           "-c:v", "libx264", "-preset", a.preset, "-crf", str(a.crf), "-threads", str(a.threads),
           "-x264-params", "rc-lookahead=10:bframes=2:ref=2", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", a.out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(n):
        t = a.start + i / a.fps
        p.stdin.write(r.frame(t).tobytes())
        if i % 60 == 0:
            print(f"\r{i}/{n}  t={t:6.1f}s", end="", file=sys.stderr, flush=True)
    p.stdin.close()
    p.wait()
    print(f"\nготово: {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
