#!/usr/bin/env python3
"""
CINEMA-рендер клипа с текстом (розово-магентовый нуар + Playfair Italic + капс-кикер).

  python3 render3.py --project ../projects/fbm.json --out /tmp/fbm.mp4
  python3 render3.py --project ../projects/dtam.json --start 23.6 --end 38.3 --out /tmp/t.mp4

Конфиг проекта (JSON): lyrics, audio, platedir, plates, energy, beats, scenes, kickers, title_card, duration.
"""
import argparse, json, math, os, subprocess, sys
import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont

D = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(D)
FFMPEG = "/home/user/ffmpeg"
if not os.path.exists(FFMPEG):
    import imageio_ffmpeg
    FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()

ACCENT = (255, 38, 126)
WHITE = (255, 255, 255)


def ensure_wav(src):
    dst = "/tmp/" + os.path.splitext(os.path.basename(src))[0] + "_render.wav"
    if not os.path.exists(dst):
        subprocess.run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", src,
                        "-ac", "2", "-ar", "44100", "-c:a", "pcm_s16le", dst], check=True)
    return dst


def paren_split(tokens):
    main, sec, depth = [], [], 0
    for w in tokens:
        t = w["w"]
        if "(" in t:
            depth += 1
        (sec if depth > 0 else main).append(w)
        if ")" in t:
            depth = max(0, depth - 1)
    return main, sec


class CinemaRenderer:
    def __init__(self, cfg, W=1920, H=1080, fps=30):
        self.cfg = cfg
        self.W, self.H, self.fps, self.s = W, H, fps, W / 1920.0
        s = self.cfg_dir = None
        s = self.s
        self.LYR = json.load(open(os.path.join(D, cfg["lyrics"]), encoding="utf-8"))
        self.ENER = json.load(open(os.path.join(D, cfg["energy"])))
        self.beats = np.array(json.load(open(os.path.join(D, cfg["beats"])))["beats"])
        self.scenes = [tuple(x) for x in cfg["scenes"]]
        self.kickers = cfg.get("kickers", {})
        self.reveal = cfg.get("reveal", "word")
        self.cur_accent = cfg.get("current_accent", True)
        self.dust_size = cfg.get("dust_size", 1.0)
        self.dust_amt = cfg.get("dust_amt", 1.0)
        self.desat = cfg.get("desat", 0.0)
        self.scrim = cfg.get("scrim", 0.0)
        self.bar = int(cfg.get("bar", 0) * self.s)
        self.sweep = cfg.get("sweep", 0.0)
        self.weave = cfg.get("weave", 0.0)
        self.rule = cfg.get("kicker_rule", False)
        self.text_y = cfg.get("text_y", 0.40)
        self.text_x = cfg.get("text_x", 0.085)
        self.flicker = cfg.get("flicker", 0.0)
        self.shake = cfg.get("shake", 0.0)
        self.punch = cfg.get("punch", 0.0)
        self.glitch = cfg.get("glitch", 0.0)
        self.ru_bar = cfg.get("ru_bar", True)
        self.ru_fixed = cfg.get("ru_fixed", False)
        self.hud = cfg.get("hud", "")
        self.gain = cfg.get("gain", 1.0)
        self.align = cfg.get("align", "left")
        self.text_anim = cfg.get("text_anim", "fade")
        self.font = cfg.get("font", "Playfair-Italic.ttf")
        self.font_w = cfg.get("font_weight", 540)
        self.size_base = cfg.get("size_base", 108)
        self.flash = cfg.get("flashlight", 0.0)
        self.scares = cfg.get("scares", [])
        self.chroma = cfg.get("chroma", 0.0)
        self.reveal_time = cfg.get("reveal_time", 0.14)
        self.drips = cfg.get("drips", 0.0)
        self.bolts = cfg.get("bolts", 0.0)
        self.kicker_once = cfg.get("kicker_once", False)
        global ACCENT
        ACCENT = tuple(cfg.get("accent", ACCENT))
        self.title_card = cfg.get("title_card")
        self.f_kick = self._font("Montserrat-Bold.ttf", int(25 * s))
        self.plate = {}
        for n in cfg["plates"]:
            p = os.path.join(D, cfg["platedir"], n + ".jpg")
            self.plate[n] = self.grade(Image.open(p).convert("RGB").resize((W, H), Image.LANCZOS))
        rng = np.random.default_rng(11)
        n = 22
        self.part = dict(x=rng.random(n), y=rng.random(n), r=rng.uniform(0.005, 0.020, n),
                         sp=rng.uniform(0.08, 0.3, n), ph=rng.uniform(0, 6.28, n))
        self.grain = []
        for _ in range(6):
            g = rng.normal(0, 20, (H // 4, W // 4, 1)).repeat(3, 2)
            self.grain.append(Image.fromarray((128 + g).clip(0, 255).astype(np.uint8)).resize((W, H), Image.BILINEAR))
        if self.hud:
            sl = np.zeros((H, W, 4), np.uint8)
            sl[0::3, :, 3] = 44
            self.scan = Image.fromarray(sl, "RGBA")
        self.lay = {}
        self.gcache = {}
        self.sec_first = {}
        for l in self.LYR["lines"]:
            self.sec_first.setdefault(l["section"], l["index"])
        self.layout_all()

    # ---------- шрифты / грейд ----------
    def _font(self, name, size, weight=None):
        f = ImageFont.truetype(os.path.join(D, "fonts", name), size)
        if weight:
            try:
                f.set_variation_by_axes([weight])
            except Exception:
                pass
        return f

    def grade(self, im):
        a = np.asarray(im, dtype=np.float32) / 255.0 * self.gain
        if self.desat > 0:
            g = a @ np.array([0.30, 0.59, 0.11], np.float32)
            a = a * (1 - self.desat) + g[..., None] * self.desat
        a = a * np.array([1.06, 0.92, 1.02], np.float32)
        a = np.clip((a - 0.5) * 1.12 + 0.44, 0, 1)
        a = a ** np.array([1.02, 1.06, 0.98], np.float32)
        H, W = a.shape[:2]
        yv = (np.arange(H, dtype=np.float32) / H)[:, None]
        xv = (np.arange(W, dtype=np.float32) / W)[None, :]
        vig = 1.0 - 0.52 * (((xv - 0.5) ** 2 * 1.1 + (yv - 0.5) ** 2) / 0.6)
        scr = 1.0 - 0.42 * np.exp(-(((xv - 0.16) / 0.46) ** 2))
        if self.scrim > 0:
            blob = np.exp(-(((xv - 0.20) / 0.46) ** 2 + ((yv - 0.45) / 0.60) ** 2))
            a = a * np.clip(1.0 - self.scrim * blob, 0.25, 1.0)[..., None]
        a = a * np.clip(vig, 0.28, 1.0)[..., None] * scr[..., None]
        return Image.fromarray(np.clip(a * 255, 0, 255).astype(np.uint8))

    # ---------- раскладка ----------
    def layout_all(self):
        s = self.s
        maxw = self.W * 0.78
        for i, l in enumerate(self.LYR["lines"]):
            main, sec = paren_split(l["words"])
            size = self.size_base
            while size > 54:
                f = self._font(self.font, int(size * s), weight=self.font_w)
                if len(self.wrap([w["w"] for w in main], f, maxw)) <= 2:
                    break
                size -= 4
            f = self._font(self.font, int(size * s), weight=self.font_w)
            rows = self.wrap([w["w"] for w in main], f, maxw)
            lh = int(size * s * 1.28)
            main_layout, k = [], 0
            for row in rows:
                x = 0.0
                xs = []
                for word in row:
                    wd = f.getlength(word)
                    xs.append((main[k]["w"], x, wd, main[k]["start"], main[k]["end"],
                               bool(main[k].get("hot")), main[k]["end"]))
                    x += wd + f.getlength(" ")
                    k += 1
                main_layout.append(xs)
            sec_layout = []
            fs = None
            slh = 0
            if sec:
                fs = self._font("Playfair-Italic.ttf", int(size * 0.52 * s), weight=520)
                srows = self.wrap([w["w"] for w in sec], fs, maxw * 0.92)
                slh = int(size * 0.52 * s * 1.2)
                k = 0
                for row in srows:
                    x = 0.0
                    xs = []
                    for word in row:
                        wd = fs.getlength(word)
                        xs.append((sec[k]["w"], x, wd, sec[k]["start"], sec[k]["end"],
                               bool(sec[k].get("hot")), sec[k]["end"]))
                        x += wd + fs.getlength(" ")
                        k += 1
                    sec_layout.append(xs)
            ru = l.get("ru")
            f_ru = self._font("Montserrat-Medium.ttf", int(35 * s)) if ru else None
            ru_rows = self.wrap(ru.split(), f_ru, maxw * 0.78) if ru else []
            rlh = int(35 * s * 1.34)
            glyphs = []
            if self.text_anim in ("ink", "glitch"):
                for ri, row in enumerate(main_layout):
                    gro = []
                    for (word, x, wd, st, en, hot, wen) in row:
                        n = len(word)
                        for j, chv in enumerate(word):
                            ax = f.getlength(word[:j])
                            t0 = st + min(0.18, j * 0.018)
                            gro.append((chv, x + ax, t0, wen, bool(hot)))
                    glyphs.append(gro)
            self.lay[i] = dict(main=main_layout, sec=sec_layout, glyphs=glyphs, f=f, fs=fs, lh=lh, slh=slh,
                               f_ru=f_ru, ru_rows=ru_rows, rlh=rlh,
                               ru_h=((len(ru_rows) * rlh + int(42 * s))
                                     if (ru_rows and not self.ru_fixed) else 0))

    @staticmethod
    def wrap(words, font, maxw):
        rows, cur, w = [], [], 0.0
        sp = font.getlength(" ")
        for word in words:
            wl = font.getlength(word)
            if cur and w + sp + wl > maxw:
                rows.append(cur)
                cur, w = [word], wl
            else:
                w += (sp if cur else 0) + wl
                cur.append(word)
        if cur:
            rows.append(cur)
        return rows

    # ---------- фон ----------
    def scene(self, t):
        for a, b, p in self.scenes:
            if a <= t < b:
                return a, b, p
        return self.scenes[-1]

    def bg(self, t):
        a, b, name = self.scene(t)
        idx = [i for i, sc in enumerate(self.scenes) if sc[0] == a][0]
        u = (t - a) / max(0.1, b - a)
        amp = 0.10 + 0.03 * (idx % 3)
        z = 1.04 + amp * (0.5 - 0.5 * math.cos(u * math.pi * 2))
        dirx = 1 if idx % 2 == 0 else -1
        cx = 0.5 + dirx * 0.035 * math.sin(u * math.pi) + 0.01 * math.sin(t * 0.4)
        cy = 0.5 + 0.03 * math.cos(u * math.pi * 1.3)
        W, H = self.W, self.H
        w, h = W / z, H / z
        x0 = min(max(0.0, cx * W - w / 2), W - w)
        y0 = min(max(0.0, cy * H - h / 2), H - h)
        return self.plate[name].crop((int(x0), int(y0), int(x0 + w), int(y0 + h))).resize((W, H), Image.BILINEAR)

    def dust(self, t, low, pulse):
        lw, lh = self.W // 4, self.H // 4
        xs = np.arange(lw, dtype=np.float32)[None, :] / lw
        ys = np.arange(lh, dtype=np.float32)[:, None] / lh
        acc = np.zeros((lh, lw), dtype=np.float32)
        for k in range(len(self.part["x"])):
            px = self.part["x"][k] + 0.04 * math.sin(t * self.part["sp"][k] * 2 + self.part["ph"][k])
            py = (self.part["y"][k] - 0.02 * t * self.part["sp"][k]) % 1.0
            pr = self.part["r"][k] * (1.0 + 0.5 * low) / 0.22 * self.dust_size
            acc += np.exp(-(((xs - px) / pr) ** 2 + ((ys - py) / pr) ** 2) * 2.5) * (0.30 + 0.35 * pulse) * self.dust_amt
        beam = np.exp(-((xs - 0.30 - 0.05 * math.sin(t * 0.2)) / 0.16) ** 2) * np.clip(1.2 - ys, 0, 1)
        acc += beam * (0.10 + 0.06 * pulse)
        layer = Image.fromarray(np.clip(acc * 255, 0, 255).astype(np.uint8)).resize((self.W, self.H), Image.BILINEAR)
        return ImageChops.multiply(layer.convert("RGB"), Image.new("RGB", (self.W, self.H), (255, 214, 228)))

    # ---------- текст ----------
    def text_layer(self, t):
        W, H, s = self.W, self.H, self.s
        layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        li = -1
        for i, l in enumerate(self.LYR["lines"]):
            if l["start"] <= t < l["end"]:
                li = i
                break
        tc = self.title_card
        if li < 0:
            if tc and tc["start"] <= t < tc["end"]:
                self.draw_title(layer, glow, t, tc)
            return layer, glow
        L = self.lay[li]
        l = self.LYR["lines"][li]
        n_rows = len(L["main"]) + (1 if L["sec"] else 0)
        block_h = len(L["main"]) * L["lh"] + (L["slh"] if L["sec"] else 0) + L["ru_h"]
        x0 = int(W * self.text_x)
        y0 = int(H * self.text_y - block_h * 0.45)
        maxy = H - self.bar - int(34 * s)
        if y0 + block_h > maxy:
            y0 = maxy - block_h
        y0 = max(int(24 * s) + self.bar, y0)
        d = ImageDraw.Draw(layer)
        kick_fade = min(1.0, (t - l["start"]) / 0.25)
        kick = self.kickers.get(l["section"], self.LYR.get("title", ""))
        if self.kicker_once and l["index"] != self.sec_first.get(l["section"]):
            kick = ""
        if kick:
            kx = x0
            if self.align == "center":
                kx = (W - self.f_kick.getlength(" ".join(kick))) / 2
            d.text((kx + int(3 * s), y0 - int(52 * s)), " ".join(kick),
                   font=self.f_kick, fill=(255, 255, 255, int(215 * kick_fade)))
            if self.rule:
                rx = x0 - (int(36 * s) if self.align == "center" else 0)
                d.rectangle([rx, y0 - int(24 * s), rx + int(72 * s * kick_fade), y0 - int(21 * s)],
                            fill=ACCENT + (int(230 * kick_fade),))
        if self.text_anim in ("ink", "glitch"):
            if self.text_anim == "glitch":
                self.draw_glitch(layer, glow, t, l, L, x0, y0)
            else:
                self.draw_ink(layer, glow, t, l, L, x0, y0)
            kick_fade_i = min(1.0, (t - l["start"]) / 0.25)
            kick_i = self.kickers.get(l["section"], self.LYR.get("title", ""))
            if self.kicker_once and l["index"] != self.sec_first.get(l["section"]):
                kick_i = ""
            if kick_i:
                kx = x0
                txt_k = " ".join(kick_i)
                if self.align == "center":
                    kx = (W - self.f_kick.getlength(txt_k)) / 2
                dy_k = int((1 - min(1.0, (t - l["start"]) / 0.35)) * 14 * s)
                d = ImageDraw.Draw(layer)
                d.text((kx + int(3 * s), y0 - int(52 * s) + dy_k), txt_k,
                       font=self.f_kick, fill=(255, 255, 255, int(215 * min(1.0, (t - l["start"]) / 0.35))))
                if self.rule:
                    kp = min(1.0, (t - l["start"]) / 0.5)
                    rx = kx - (int(36 * s) if self.align == "center" else 0)
                    d.rectangle([rx, y0 - int(24 * s), rx + int(72 * s * kp), y0 - int(21 * s)],
                                fill=ACCENT + (int(230 * kp),))
            if L["ru_rows"]:
                a2 = min(1.0, max(0.0, (t - l["start"]) / 0.4))
                ry = H - self.bar - int(62 * s) - len(L["ru_rows"]) * L["rlh"]
                for ri, row in enumerate(L["ru_rows"]):
                    txt = " ".join(row)
                    rx0 = x0
                    if self.align == "center":
                        rx0 = (W - L["f_ru"].getlength(txt)) / 2
                    dy_r = int((1 - a2) * 12 * s)
                    ImageDraw.Draw(layer).text((rx0, ry + ri * L["rlh"] + dy_r), txt,
                                               font=L["f_ru"], fill=(244, 241, 233, int(236 * a2)))
            return layer, glow
        gi = 0
        for ri, row in enumerate(L["main"]):
            for (word, x, wd, st, en, hot, *_we) in row:
                st = l["start"] + gi * 0.045 if self.reveal == "line" else st
                gi += 1
                if t < st - 0.06:
                    continue
                a = min(1.0, max(0.0, (t - (st - 0.06)) / 0.16))
                dy = int((1 - a) * 10 * s)
                shown = word
                if self.reveal == "letter" and t < en:
                    prog = max(0.0, (t - st) / max(0.10, en - st))
                    shown = word[:max(1, int(math.ceil(len(word) * min(1.0, prog))))]
                if hot:
                    col = ACCENT
                else:
                    col = ACCENT if (self.cur_accent and t < en) else WHITE
                cdx = 0.0
                if self.align == "center":
                    cdx = (W - (L["main"][ri][-1][1] + L["main"][ri][-1][2])) / 2 - x0
                xx, yy = x0 + x + cdx, y0 + ri * L["lh"] + dy
                d.text((xx + 2 * s, yy + 3 * s), shown, font=L["f"], fill=(0, 0, 0, int(150 * a)))
                d.text((xx, yy), shown, font=L["f"], fill=col + (int(255 * a),))
                if col == ACCENT:
                    ImageDraw.Draw(glow).text((xx, yy), shown, font=L["f"], fill=ACCENT + (255,))
        if L["sec"]:
            fs = L["fs"]
            sy = y0 + len(L["main"]) * L["lh"] + int(26 * s)
            for ri, row in enumerate(L["sec"]):
                for (word, x, wd, st, en, hot, *_we) in row:
                    if t < st - 0.06:
                        continue
                    prog = min(1.0, max(0.0, (t - (st - 0.06)) / max(0.08, (en - st + 0.06))))
                    shown = word[:max(1, int(round(len(word) * prog)))]
                    xx, yy = x0 + x, sy + ri * L["slh"]
                    d.text((xx + 2 * s, yy + 2 * s), shown, font=fs, fill=(0, 0, 0, 150))
                    d.text((xx, yy), shown, font=fs, fill=ACCENT + (255,))
                    ImageDraw.Draw(glow).text((xx, yy), shown, font=fs, fill=ACCENT + (200,))
        if L["ru_rows"]:
            a2 = min(1.0, max(0.0, (t - l["start"]) / 0.35))
            if self.ru_fixed:
                ry = H - self.bar - int(62 * s) - len(L["ru_rows"]) * L["rlh"]
            else:
                ry = y0 + len(L["main"]) * L["lh"] + (L["slh"] if L["sec"] else 0) + int(42 * s)
            if self.ru_bar:
                d.rectangle([rx0 - int(20 * s), ry + int(4 * s), rx0 - int(16 * s),
                             ry + len(L["ru_rows"]) * L["rlh"] - int(6 * s)], fill=ACCENT + (int(190 * a2),))
            for ri, row in enumerate(L["ru_rows"]):
                txt = " ".join(row)
                rx0 = x0
                if self.align == "center":
                    rx0 = (W - L["f_ru"].getlength(txt)) / 2
                d.text((rx0, ry + ri * L["rlh"]), txt, font=L["f_ru"],
                       fill=(244, 241, 233, int((222 if not self.ru_fixed else 236) * a2)))
        return layer, glow

    def _glyph(self, ch, col, fs):
        key = (ch, col, fs)
        g = self.gcache.get(key)
        if g is None:
            f = self._font(self.font, fs, weight=self.font_w)
            gw = int(math.ceil(f.getlength(ch))) + 4
            gh = int(fs * 1.35)
            g = Image.new("RGBA", (gw, gh), (0, 0, 0, 0))
            ImageDraw.Draw(g).text((2, int(fs * 0.12)), ch, font=f, fill=col + (255,))
            self.gcache[key] = g
        return g

    def draw_ink(self, layer, glow, t, l, L, x0, y0):
        """"чернильный" текст: вся строка видна призраком, спетые слова всплывают и наливаются"""
        W, H, s = self.W, self.H, self.s
        fs = int(round(L["f"].size))
        GHOST = (232, 226, 220)
        for ri, gro in enumerate(L["glyphs"]):
            base = y0 + ri * L["lh"]
            row = L["main"][ri]
            cdx = 0.0
            if self.align == "center" and row:
                cdx = (W - (row[-1][1] + row[-1][2])) / 2 - x0
            for (chv, gx, t0, wen, hot) in gro:
                gx = gx + cdx
                p = (t - t0) / 0.14
                acc_on = hot or (self.cur_accent and t < wen)
                px0 = int(round(x0 + gx - 2))
                if p <= 0:
                    g = self._glyph(chv, GHOST, fs)
                    m = np.asarray(g.split()[3], dtype=np.float32) * 0.34
                    mk = Image.fromarray(np.clip(m, 0, 255).astype(np.uint8))
                    py = int(round(base + L["lh"] * 0.8 - g.height))
                    layer.paste(g, (px0, py), mk)
                    continue
                p = min(1.0, p)
                ease = p * p * (3 - 2 * p)
                col = ACCENT if acc_on else WHITE
                g = self._glyph(chv, col, fs)
                rise = int((1 - ease) ** 2 * 40 * s)
                stretch = 1.0 + 0.3 * (1 - ease)
                hh = max(2, int(g.height * stretch))
                g2 = g.resize((g.width, hh), Image.BILINEAR)
                py = int(round(base + L["lh"] * 0.8 - hh + rise))
                m = np.asarray(g2.split()[3], dtype=np.float32) * min(1.0, ease * 1.6)
                mk = Image.fromarray(np.clip(m, 0, 255).astype(np.uint8))
                sh = self._glyph(chv, (0, 0, 0), fs).resize((g2.width, g2.height), Image.BILINEAR)
                layer.paste(sh, (px0 + int(3 * s), py + int(4 * s)), mk)
                layer.paste(g2, (px0, py), mk)
                if acc_on:
                    glow.paste(g2, (px0, py), mk)
        # алая линия тянется по всей спетой части строки + капля с конца
        d = ImageDraw.Draw(layer)
        for ri, row in enumerate(L["main"]):
            if not row:
                continue
            yy = y0 + ri * L["lh"] + int(L["lh"] * 0.95)
            cdx2 = 0.0
            if self.align == "center":
                cdx2 = (W - (row[-1][1] + row[-1][2])) / 2 - x0
            x_start = x0 + row[0][1] + cdx2
            tip = x_start
            tip_t = None
            for (word, x, wd, st, en, hot, wen) in row:
                if t < st:
                    break
                prog = min(1.0, (t - st) / max(0.12, en - st))
                tip = x0 + x + cdx2 + wd * prog
                tip_t = en
            if tip <= x_start + 1:
                continue
            k = min(1.0, (t - row[0][3]) / 0.12)
            d.rectangle([x_start, yy, tip, yy + max(2, int(3 * s))], fill=ACCENT + (int(200 * k),))
            if tip_t is not None and t > tip_t:
                f2 = min(1.0, (t - tip_t) / 0.6)
                dy = int(f2 * 56 * s)
                d.rectangle([tip - int(1.5 * s), yy, tip + int(1.5 * s), yy + dy],
                            fill=ACCENT + (int(140 * (1 - f2)),))
                r = int((3 + 4 * f2) * s)
                d.ellipse([tip - r, yy + dy - r, tip + r, yy + dy + r],
                          fill=ACCENT + (int(185 * (1 - f2)),))

    def draw_glitch(self, layer, glow, t, l, L, x0, y0):
        """"битый экран": буквы вщёлкиваются с цветным расслоением и дрожью"""
        W, H, s = self.W, self.H, self.s
        fs = int(round(L["f"].size))
        RED = (255, 40, 60)
        CYA = (60, 235, 255)
        d = ImageDraw.Draw(layer)
        for ri, gro in enumerate(L["glyphs"]):
            base = y0 + ri * L["lh"]
            row = L["main"][ri]
            cdx = 0.0
            if self.align == "center" and row:
                cdx = (W - (row[-1][1] + row[-1][2])) / 2 - x0
            for (chv, gx, t0, wen, hot) in gro:
                age = t - t0
                if age < 0:
                    continue
                acc_on = hot or (self.cur_accent and t < wen)
                col = ACCENT if acc_on else WHITE
                g = self._glyph(chv, col, fs)
                px0 = int(round(x0 + gx + cdx - 2))
                jit = int(round(2.2 * s * math.sin((t + gx) * 71.0))) if age < 0.22 else 0
                py = int(round(base + L["lh"] * 0.8 - g.height))
                if age < 0.18:
                    k = 1.0 - age / 0.18
                    off = int(round((3 + 7 * k) * s))
                    a = int(255 * min(1.0, 0.35 + 0.65 * (1 - k)))
                    mkk = Image.fromarray(np.clip(np.asarray(g.split()[3], dtype=np.float32) * (0.45 * (1 - k) + 0.35)).astype(np.uint8))
                    for cc, dx2 in ((RED, -off), (CYA, off)):
                        gg = self._glyph(chv, cc, fs)
                        layer.paste(gg, (px0 + dx2, py + jit), mkk)
                    mg = Image.fromarray(np.clip(np.asarray(g.split()[3], dtype=np.float32) * a / 255.0).astype(np.uint8))
                    sh = self._glyph(chv, (0, 0, 0), fs)
                    layer.paste(sh, (px0 + int(3 * s), py + int(4 * s)), mg)
                    layer.paste(g, (px0, py + jit), mg)
                    if acc_on:
                        glow.paste(g, (px0, py + jit), mg)
                else:
                    m = g.split()[3]
                    sh = self._glyph(chv, (0, 0, 0), fs)
                    layer.paste(sh, (px0 + int(3 * s), py + int(4 * s)), m)
                    layer.paste(g, (px0, py), m)
                    if acc_on:
                        glow.paste(g, (px0, py), m)
        # редкие горизонтальные срывы строки
        hh = (math.sin(t * 53.3 + 2.1) * 4391.7) % 1.0
        if hh < 0.10:
            yy = y0 + int(((math.sin(t * 17.0) * 0.5 + 0.5)) * L["lh"] * max(1, len(L["main"])))
            d.rectangle([0, yy, W, yy + max(2, int(3 * s))], fill=(255, 255, 255, 42))

    def draw_title(self, layer, glow, t, tc):
        """финальная/стартовая плашка: ( FBM ) + кикер"""
        W, H, s = self.W, self.H, self.s
        dur = tc["end"] - tc["start"]
        u = (t - tc["start"]) / dur
        a = min(1.0, min(u / 0.18, (1 - u) / 0.18))
        a = max(0.0, a)
        size = 150
        deco = f"( {tc.get('main', '')} )"
        while size > 60:
            f = self._font("Playfair-Italic.ttf", int(size * s), weight=540)
            if f.getlength(deco) <= self.W * 0.80:
                break
            size -= 4
        f = self._font("Playfair-Italic.ttf", int(size * s), weight=540)
        txt = tc.get("main", "")
        wd = f.getlength(deco)
        x = (W - wd) / 2
        y = H * 0.42
        d = ImageDraw.Draw(layer)
        d.text((x + 3 * s, y + 3 * s), deco, font=f, fill=(0, 0, 0, int(160 * a)))
        d.text((x, y), deco, font=f, fill=(255, 255, 255, int(255 * a)))
        ImageDraw.Draw(glow).text((x, y), deco, font=f, fill=(255, 90, 150, int(160 * a)))
        top = tc.get("top", "")
        if top:
            fk = self._font("Montserrat-Bold.ttf", int(26 * s))
            t2 = " ".join(top)
            d.text(((W - fk.getlength(t2)) / 2, y - int(52 * s)), t2, font=fk, fill=(255, 255, 255, int(220 * a)))

    def draw_hud(self, img, t):
        """оверлей «камеры наблюдения» в духе FNAF"""
        W, H, s = self.W, self.H, self.s
        d = ImageDraw.Draw(img, "RGBA")
        col = (240, 240, 240)
        top = self.bar + int(30 * s)
        bot = H - self.bar - int(34 * s)
        left, right = int(56 * s), W - int(56 * s)
        f = self._font("Montserrat-Bold.ttf", int(28 * s))
        f2 = self._font("Montserrat-Medium.ttf", int(23 * s))
        cam = f"CAM 0{1 + int(t // 17) % 4}"
        d.text((left, top), cam, font=f, fill=col + (232,))
        sec = int(t) % 60
        stamp = f"REC 03:{int(t // 60) + 1:02d}:{sec:02d}"
        tw = f2.getlength(stamp)
        d.text((right - tw, top + int(5 * s)), stamp, font=f2, fill=col + (205,))
        if (t * 1.6) % 1.0 < 0.6:
            x = right - tw - int(26 * s)
            d.ellipse([x, top + int(11 * s), x + int(15 * s), top + int(26 * s)],
                      fill=(232, 38, 38, 240))
        night = f"NIGHT {1 + int(t // 26) % 5}"
        d.text((left, top + int(38 * s)), night, font=f2, fill=(226, 226, 226, 165))
        L, w = int(52 * s), max(2, int(3 * s))
        for (x, y, sx, sy) in ((left - 18, top - 14, 1, 1), (right + 18, top - 14, -1, 1),
                               (left - 18, bot + 14, 1, -1), (right + 18, bot + 14, -1, -1)):
            d.line([(x, y), (x + sx * L, y)], fill=(235, 235, 235, 130), width=w)
            d.line([(x, y), (x, y + sy * L)], fill=(235, 235, 235, 130), width=w)
        return img

    def draw_drips(self, img, t):
        """капли крови, стекающие с верхней полосы"""
        if self.drips <= 0:
            return img
        W, H, s = self.W, self.H, self.s
        d = ImageDraw.Draw(img, "RGBA")
        n = 7
        for k in range(n):
            ph = (math.sin(k * 12.9898 + 4.1) * 43758.5453) % 1.0
            fx = 0.06 + 0.88 * ((math.sin(k * 7.13 + 1.7) * 24634.6) % 1.0)
            per = 5.0 + 6.0 * ph
            u = ((t / per) + ph) % 1.0
            L = int((0.05 + 0.30 * ph) * H * (u ** 0.75))
            w = max(2, int((3 + 7 * ph) * s * (1.0 - 0.45 * u)))
            x = int(fx * W)
            y0 = self.bar
            a = int(self.drips * 210 * min(1.0, (1.0 - u) * 3.2))
            if a <= 4 or L < 3:
                continue
            d.rectangle([x - w // 2, y0, x + w // 2, y0 + L], fill=(116, 8, 14, a))
            r = w * 0.9
            d.ellipse([x - r, y0 + L - r, x + r, y0 + L + r], fill=(132, 10, 16, a))
            if u > 0.72:
                fy = y0 + L + int((u - 0.72) * 900 * s)
                if fy < H - self.bar - 6:
                    d.ellipse([x - 3 * s, fy - 5 * s, x + 3 * s, fy + 5 * s], fill=(126, 9, 15, a))
        return img

    def bolt(self, out, t):
        """короткие вспышки молнии над собором"""
        if self.bolts <= 0:
            return out
        for k in range(2):
            ph = (math.sin(k * 31.7 + 2.3) * 9137.1) % 1.0
            per = 9.0 + 8.0 * ph
            u = ((t / per) + ph) % 1.0
            if u < 0.014:
                g = max(0.0, 1.0 - abs(u - 0.006) / 0.008)
                amt = self.bolts * 95 * g
                out = ImageChops.add(out, Image.new("RGB", out.size,
                                                    (int(amt), int(amt * 0.96), int(amt * 1.35))))
        return out

    def apply_flashlight(self, plate, t, pulse):
        """луч фонарика: всё вне конуса уходит в темноту, в луче — тёплый свет"""
        W, H = self.W, self.H
        lw, lh = W // 4, H // 4
        xs = np.arange(lw, dtype=np.float32)[None, :] / lw
        ys = np.arange(lh, dtype=np.float32)[:, None] / lh
        cx = 0.50 + 0.16 * math.sin(t * 0.37) + 0.06 * math.sin(t * 0.91 + 1.3)
        cy = 0.47 + 0.09 * math.cos(t * 0.29 + 0.7)
        r = 0.34 + 0.015 * math.sin(t * 1.9) + 0.05 * pulse
        d2 = ((xs - cx) ** 2 + ((ys - cy) * 1.45) ** 2) / (r * r)
        core = np.exp(-(d2 ** 1.5))
        m = (1.0 - self.flash) + self.flash * core
        warm = 1.0 + core * 0.45
        col = np.stack([m * warm * 1.06, m * warm, m * warm * 0.86], -1)
        col = np.clip(col / 1.6, 0.0, 1.0) * 255.0
        img = Image.fromarray(col.astype(np.uint8)).resize((W, H), Image.BILINEAR)
        arr = np.asarray(plate).astype(np.float32) * (np.asarray(img).astype(np.float32) / 255.0 * 1.6)
        return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

    def scare_frame(self, plate, t):
        """скрим-кадр: лицо/силуэт вплотную, расслоение каналов, рывок"""
        for (ts, dur, nm) in self.scares:
            if ts <= t < ts + dur:
                u = (t - ts) / max(0.01, dur)
                src = self.plate.get(nm, plate)
                W, H = self.W, self.H
                z = 1.16 - 0.16 * u
                w, h = int(W / z), int(H / z)
                x0 = (W - w) // 2 + int(22 * math.sin(t * 61))
                y0 = (H - h) // 2 + int(10 * math.cos(t * 47))
                fr = src.crop((max(0, x0), max(0, y0), min(W, x0 + w), min(H, y0 + h))).resize((W, H), Image.BILINEAR)
                fr = ImageEnhance.Contrast(fr).enhance(1.25 + 0.5 * (1 - u))
                fr = ImageEnhance.Brightness(fr).enhance(1.05 + 0.25 * (1 - u))
                ar = np.asarray(fr).astype(np.int16)
                dx = int(14 * (1 - u)) + 4
                ar[..., 0] = np.roll(ar[..., 0], dx, axis=1)
                ar[..., 2] = np.roll(ar[..., 2], -dx, axis=1)
                return Image.fromarray(np.clip(ar, 0, 255).astype(np.uint8)), True
        return plate, False

    # ---------- кадр ----------
    def frame(self, t):
        W, H = self.W, self.H
        nmax = min(len(self.ENER[k]) for k in ("rms", "low", "high"))
        fi = min(nmax - 1, max(0, int(t * self.ENER["fps"])))
        rms, low, high = self.ENER["rms"][fi], self.ENER["low"][fi], self.ENER["high"][fi]
        bi = np.searchsorted(self.beats, t) - 1
        pulse = math.exp(-(t - self.beats[bi]) * 6.0) if 0 <= bi < len(self.beats) else 0.0

        plate = self.bg(t)
        a_s, b_s, _nm = self.scene(t)
        u_s = (t - a_s) / max(0.1, b_s - a_s)
        if self.punch > 0:
            pz = 1.0 + self.punch * math.exp(-u_s * 7.0)
            cw, ch = max(8, int(W / pz)), max(8, int(H / pz))
            x0 = (W - cw) // 2 + int(self.punch * 40 * math.exp(-u_s * 7.0))
            y0 = (H - ch) // 2
            plate = plate.crop((x0, y0, x0 + cw, y0 + ch)).resize((W, H), Image.BILINEAR)
        if self.shake > 0:
            amp = self.shake * (0.35 + 2.2 * pulse)
            sx = int(round(amp * math.sin(t * 37.0) + amp * 0.6 * math.sin(t * 91.0)))
            sy = int(round(amp * math.cos(t * 43.0)))
            m = int(abs(amp)) + 6
            plate = plate.crop((m + sx, m + sy, W - m + sx, H - m + sy)).resize((W, H), Image.BILINEAR)
        if self.glitch > 0:
            h2 = (math.sin(t * 311.7 + 1.3) * 24634.6345) % 1.0
            near = any(abs(t - l["start"]) < 0.16 for l in self.LYR["lines"])
            if h2 < self.glitch * (0.55 if near else 0.22):
                ar = np.asarray(plate).astype(np.int16)
                for bi in range(2):
                    hb = (math.sin(t * 57.0 + bi * 12.9) * 9999.0) % 1.0
                    y1 = int(hb * (H - 50))
                    y2 = y1 + int(14 + 40 * ((hb * 7.3) % 1.0))
                    dx = int(4 + 10 * ((hb * 3.1) % 1.0))
                    ar[y1:y2, :, 0] = np.roll(ar[y1:y2, :, 0], dx, axis=1)
                    ar[y1:y2, :, 2] = np.roll(ar[y1:y2, :, 2], -dx, axis=1)
                plate = Image.fromarray(np.clip(ar, 0, 255).astype(np.uint8))
        if self.weave > 0:
            dx = int(round(self.weave * 2.0 * math.sin(t * 19.0 + 1.3)))
            dy = int(round(self.weave * 2.0 * math.cos(t * 13.0)))
            m = 4
            plate = plate.crop((m + dx, m + dy, W - m + dx, H - m + dy)).resize((W, H), Image.BILINEAR)
        if pulse > 0.02:
            plate = ImageEnhance.Brightness(plate).enhance(1.0 + 0.06 * pulse)
        if self.chroma > 0 and pulse > 0.30:
            k = int(self.chroma * 14 * pulse)
            if k >= 1:
                ar = np.asarray(plate).astype(np.int16)
                ar[..., 0] = np.roll(ar[..., 0], k, axis=1)
                ar[..., 2] = np.roll(ar[..., 2], -k, axis=1)
                plate = Image.fromarray(np.clip(ar, 0, 255).astype(np.uint8))
        scare_on = False
        if self.scares:
            plate, scare_on = self.scare_frame(plate, t)
        if self.flash > 0 and not scare_on:
            plate = self.apply_flashlight(plate, t, pulse)
        if self.dust_amt > 0:
            plate = ImageChops.add(plate, self.dust(t, low, pulse))
        img = plate.convert("RGBA")

        if self.sweep > 0:
            xs = np.arange(W, dtype=np.float32)[None, :] / W
            ys = np.arange(H, dtype=np.float32)[:, None] / H
            pos = (t * 0.16) % 1.6 - 0.3
            band = np.exp(-((xs + ys * 0.45 - pos) / 0.10) ** 2) * self.sweep
            arr = np.zeros((H, W, 4), np.uint8)
            arr[..., :3] = np.array([255, 243, 226], np.uint8)
            arr[..., 3] = (np.clip(band, 0, 1) * 255).astype(np.uint8)
            img = Image.alpha_composite(img, Image.fromarray(arr, "RGBA"))
        layer, glow = self.text_layer(t)
        sm = glow.resize((W // 3, H // 3), Image.BILINEAR).filter(ImageFilter.GaussianBlur(7))
        img = Image.alpha_composite(img, sm.resize((W, H), Image.BILINEAR))
        img = Image.alpha_composite(img, layer)

        a, b, name = self.scene(t)
        if t - a < 0.16:
            fa = int(105 * (1 - (t - a) / 0.16) ** 2)
            img.alpha_composite(Image.new("RGBA", (W, H), (255, 232, 240, fa)))

        out = Image.blend(img.convert("RGB"), self.grain[int(t * 12) % len(self.grain)], 0.07)
        if self.flicker > 0:
            h1 = (math.sin(t * 127.1 + 3.7) * 43758.5453) % 1.0
            k = 1.0
            if h1 < 0.040:
                k = 0.62
            elif h1 < 0.10:
                k = 0.88
            if k != 1.0:
                out = ImageEnhance.Brightness(out).enhance(k)
        if self.hud:
            out = self.draw_hud(out, t)
            out = Image.alpha_composite(out.convert("RGBA"), self.scan).convert("RGB")
            h3 = (math.sin(t * 91.7 + 6.1) * 13579.2468) % 1.0
            if h3 < 0.026:
                g = self.grain[int(t * 12) % len(self.grain)]
                out = Image.blend(out, g, 0.11)
                dy = int(6 * ((h3 * 47) % 1.0))
                out = ImageChops.offset(out, 0, dy)
        out = self.bolt(out, t)
        out = self.draw_drips(out, t)
        if self.bar > 0:
            d2 = ImageDraw.Draw(out)
            d2.rectangle([0, 0, W, self.bar], fill=(0, 0, 0))
            d2.rectangle([0, H - self.bar, W, H], fill=(0, 0, 0))
        return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project", required=True)
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=None)
    ap.add_argument("--out", default="/tmp/cinema.mp4")
    ap.add_argument("--w", type=int, default=1920)
    ap.add_argument("--h", type=int, default=1080)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--crf", type=int, default=20)
    ap.add_argument("--preset", default="veryfast")
    ap.add_argument("--threads", type=int, default=2)
    a = ap.parse_args()

    cfg = json.load(open(os.path.join(D, a.project), encoding="utf-8"))
    end = a.end if a.end is not None else cfg.get("duration", 60.0)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    r = CinemaRenderer(cfg, a.w, a.h, a.fps)
    n = int(round((end - a.start) * a.fps))
    cmd = [FFMPEG, "-hide_banner", "-loglevel", "error", "-y",
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{a.w}x{a.h}", "-r", str(a.fps), "-i", "-",
           "-ss", str(a.start), "-t", str(end - a.start), "-i", ensure_wav(os.path.join(D, cfg["audio"])),
           "-map", "0:v", "-map", "1:a",
           "-c:v", "libx264", "-preset", a.preset, "-crf", str(a.crf), "-threads", str(a.threads),
           "-x264-params", "rc-lookahead=10:bframes=2:ref=2", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", a.out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(n):
        t = a.start + i / a.fps
        p.stdin.write(r.frame(t).tobytes())
        if i % 60 == 0:
            print(f"\r{i}/{n}  t={t:6.1f}s", end="", file=sys.stderr, flush=True)
    p.stdin.close()
    p.wait()
    print(f"\nготово: {a.out}", file=sys.stderr)


if __name__ == "__main__":
    main()
