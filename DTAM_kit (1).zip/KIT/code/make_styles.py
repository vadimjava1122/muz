#!/usr/bin/env python3
"""Стилевые макеты кадра (1920x1080) для будущего клипа."""
import numpy as np, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

D = os.path.dirname(os.path.abspath(__file__))
F = lambda n, s: ImageFont.truetype(os.path.join(D, "fonts", n), s)
W, H = 1920, 1080
LINE = "Money, money, money, get his money,"
LINE2 = "money, money, a-ah"
TITLE = "D.T.A.M."
ARTIST = "BRITNEY MANSON"

rng = np.random.default_rng(7)

def vgrad(top, bottom, w=W, h=H):
    t = np.linspace(0, 1, h)[:, None, None]
    return Image.fromarray((np.array(top) * (1 - t) + np.array(bottom) * t).astype(np.uint8).repeat(w, 1))

def grain(img, amount=10, mono=True):
    a = np.array(img).astype(np.int16)
    n = rng.normal(0, amount, a.shape[:2] + (1,))
    if not mono:
        n = rng.normal(0, amount, a.shape)
    return Image.fromarray(np.clip(a + n, 0, 255).astype(np.uint8))

def fit_font(text, font_name, size, max_w, minsize=24):
    while size > minsize:
        f = F(font_name, size)
        if f.getlength(text) <= max_w:
            return f
        size -= 4
    return F(font_name, minsize)

def glow_layer(base, text, font, xy, color, blur=26, strength=1.0):
    lay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    d.text(xy, text, font=font, fill=color + (255,), anchor="mm")
    g = lay.filter(ImageFilter.GaussianBlur(blur))
    for _ in range(int(2 * strength)):
        base.alpha_composite(g)
    return lay

def stars(img, n=260):
    d = ImageDraw.Draw(img)
    for _ in range(n):
        x, y = rng.integers(0, W), rng.integers(0, H)
        s = rng.integers(0, 3)
        a = rng.integers(30, 110)
        d.ellipse([x, y, x + s, y + s], fill=(255, 255, 255, a))

# ------------------------------------------------------------------ A: NEON
def style_neon():
    bg = vgrad((22, 4, 34), (6, 3, 12)).convert("RGBA")
    # радиальные пятна
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    d.ellipse([-300, -400, 1100, 700], fill=(255, 46, 136, 90))
    d.ellipse([900, 400, 2200, 1500], fill=(49, 240, 255, 70))
    d.ellipse([500, -200, 1500, 500], fill=(139, 92, 246, 80))
    bg.alpha_composite(lay.filter(ImageFilter.GaussianBlur(160)))
    stars(bg)
    # рамка-полосы
    d = ImageDraw.Draw(bg)
    d.rectangle([90, 70, W - 90, H - 70], outline=(255, 255, 255, 40), width=2)
    f1 = fit_font(LINE, "Montserrat-Black.ttf", 120, 1560)
    f2 = fit_font(LINE2, "Montserrat-Black.ttf", 120, 1560)
    y1, y2 = H // 2 - 80, H // 2 + 60
    for f, t, y in ((f1, LINE, y1), (f2, LINE2, y2)):
        glow_layer(bg, t, f, (W // 2, y), (49, 240, 255), blur=34, strength=2)
        glow_layer(bg, t, f, (W // 2, y), (255, 46, 136), blur=60, strength=1)
    d = ImageDraw.Draw(bg)
    for f, t, y in ((f1, LINE, y1), (f2, LINE2, y2)):
        d.text((W // 2, y), t, font=f, fill=(255, 255, 255, 255), anchor="mm")
    # титры
    d.text((120, 120), TITLE, font=F("Montserrat-Black.ttf", 40), fill=(255, 255, 255, 220))
    d.text((W - 120, 120), ARTIST, font=F("Montserrat-Medium.ttf", 24), fill=(255, 255, 255, 150), anchor="ra")
    d.text((W // 2, H - 128), "CHORUS", font=F("Montserrat-Bold.ttf", 22), fill=(49, 240, 255, 220), anchor="mm")
    out = grain(bg, 9)
    # хроматическая аберрация
    r, g, b = out.split()[:3]
    out = Image.merge("RGB", (Image.fromarray(np.roll(np.array(r), -3, axis=1)), g,
                              Image.fromarray(np.roll(np.array(b), 3, axis=1))))
    return out

# ------------------------------------------------------------------ B: EDITORIAL
def style_editorial():
    bg = Image.new("RGBA", (W, H), (242, 240, 236, 255))
    d = ImageDraw.Draw(bg)
    # красные акценты
    d.rectangle([0, 0, W, 10], fill=(230, 30, 60))
    d.text((110, 120), "D.T.A.M.", font=F("Montserrat-Black.ttf", 96), fill=(20, 18, 22))
    d.text((114, 240), "B R I T N E Y   M A N S O N", font=F("Montserrat-Medium.ttf", 24), fill=(120, 115, 125))
    d.line([110, 300, W - 110, 300], fill=(20, 18, 22), width=3)
    f1 = fit_font(LINE, "Montserrat-Black.ttf", 110, 1660)
    f2 = fit_font(LINE2, "Montserrat-Black.ttf", 110, 1660)
    d.text((110, 400), LINE, font=f1, fill=(20, 18, 22))
    d.text((110, 540), LINE2, font=f2, fill=(230, 30, 60))
    d.text((110, H - 200), "«Не верь ни одному мужчине —\nони все делают одно и то же»", font=F("Montserrat-Medium.ttf", 34), fill=(90, 85, 95))
    d.text((W - 110, H - 140), "01 / CHORUS", font=F("Montserrat-Bold.ttf", 24), fill=(120, 115, 125), anchor="ra")
    d.line([110, H - 240, W - 110, H - 240], fill=(200, 196, 190), width=2)
    return grain(bg.convert("RGB"), 6)

# ------------------------------------------------------------------ C: GLITCH VHS
def style_glitch():
    bg = vgrad((10, 8, 14), (24, 6, 18)).convert("RGBA")
    stars(bg, 120)
    f1 = fit_font(LINE, "Montserrat-Black.ttf", 108, 1580)
    f2 = fit_font(LINE2, "Montserrat-Black.ttf", 108, 1580)
    y1, y2 = H // 2 - 70, H // 2 + 60
    for t, f, y in ((LINE, f1, y1), (LINE2, f2, y2)):
        lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        dd = ImageDraw.Draw(lay)
        dd.text((W // 2, y), t, font=f, fill=(255, 255, 255, 255), anchor="mm")
        arr = np.array(lay)
        r = np.zeros_like(arr); r[..., 0] = arr[..., 0]
        c = np.zeros_like(arr); c[..., 2] = arr[..., 0]; c[..., 1] = arr[..., 0]
        bg.alpha_composite(Image.fromarray(np.roll(r, -8, axis=1)))
        bg.alpha_composite(Image.fromarray(np.roll(c, 8, axis=1)))
        bg.alpha_composite(lay)
    img = np.array(bg).astype(np.int16)
    # сканы
    img[::4] = (img[::4] * 0.72)
    # случайные сдвиги строк
    for _ in range(9):
        y = int(rng.integers(0, H - 30))
        h = int(rng.integers(4, 26))
        img[y:y + h] = np.roll(img[y:y + h], int(rng.integers(-40, 40)), axis=1)
    out = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).convert("RGBA")
    d = ImageDraw.Draw(out)
    d.text((90, 80), "REC ●", font=F("Montserrat-Bold.ttf", 26), fill=(255, 60, 90, 230))
    d.text((W - 90, 80), "00:00:24:11", font=F("Montserrat-Medium.ttf", 26), fill=(255, 255, 255, 190), anchor="ra")
    d.text((90, H - 90), "D.T.A.M.  //  BRITNEY MANSON", font=F("Montserrat-Bold.ttf", 26), fill=(255, 255, 255, 180))
    return grain(out.convert("RGB"), 14)

# ------------------------------------------------------------------ D: SOFT KARAOKE
def style_soft():
    bg = vgrad((255, 246, 250), (232, 226, 255)).convert("RGBA")
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    d.ellipse([100, 250, 900, 1050], fill=(255, 150, 200, 170))
    d.ellipse([1000, -200, 1900, 600], fill=(150, 190, 255, 170))
    d.ellipse([700, 600, 1500, 1300], fill=(255, 220, 150, 150))
    bg.alpha_composite(lay.filter(ImageFilter.GaussianBlur(180)))
    d = ImageDraw.Draw(bg)
    f1 = fit_font(LINE, "Montserrat-Bold.ttf", 104, 1520)
    f2 = fit_font(LINE2, "Montserrat-Bold.ttf", 104, 1520)
    y1, y2 = H // 2 - 70, H // 2 + 60
    d.text((W // 2, y1), LINE, font=f1, fill=(58, 35, 80, 255), anchor="mm")
    d.text((W // 2, y2), LINE2, font=f2, fill=(58, 35, 80, 255), anchor="mm")
    # подсветка «поющейся» строки (эффект караоке)
    mask = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(mask)
    md.text((W // 2, y2), LINE2, font=f2, fill=255, anchor="mm")
    paint = Image.new("RGBA", (W, H), (226, 22, 120, 255))
    bg = Image.composite(paint, bg, mask)
    # мягкая тень под текстом
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(sh)  # светлая подложка-свечение
    sd.text((W // 2, y1 + 8), LINE, font=f1, fill=(255, 255, 255, 160), anchor="mm")
    sd.text((W // 2, y2 + 8), LINE2, font=f2, fill=(255, 255, 255, 160), anchor="mm")
    bg.alpha_composite(sh.filter(ImageFilter.GaussianBlur(10)))
    d = ImageDraw.Draw(bg)
    d.text((W // 2, H - 110), "D . T . A . M .", font=F("Montserrat-Medium.ttf", 24), fill=(120, 100, 150, 200), anchor="mm")
    return grain(bg.convert("RGB"), 5)

for name, fn in [("style_A_neon", style_neon), ("style_B_editorial", style_editorial),
                 ("style_C_glitch", style_glitch), ("style_D_soft", style_soft)]:
    im = fn()
    im.save(os.path.join(D, "img", name + ".png"))
    im.resize((640, 360)).save(os.path.join(D, "img", "small_" + name + ".png"))
    print("saved", name)
