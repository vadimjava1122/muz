#!/usr/bin/env python3
"""
Рендер клипа с текстом (D.T.A.M. — Britney Manson).

  python3 render.py --start 23.6 --end 38.3 --out out/demo.mp4     # фрагмент
  python3 render.py --out out/D.T.A.M_lyric_video.mp4               # весь трек

Стили: neon (по умолчанию), soft.
Кадры рисуются в PIL, музыкальная реактивность берётся из ../data/energy.json.
"""
import argparse, json, os, subprocess, sys, math
import numpy as np
from collections import OrderedDict
from PIL import Image, ImageDraw, ImageFont, ImageFilter

D = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(D)
LYR = json.load(open(os.path.join(ROOT, "lyrics", "lyrics_timed.json"), encoding="utf-8"))
ENER = json.load(open(os.path.join(ROOT, "data", "energy.json")))
FFMPEG = "/home/user/ffmpeg"
if not os.path.exists(FFMPEG):                       # ffmpeg ставится заново в каждой сессии
    import imageio_ffmpeg
    FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
FONTS = os.path.join(D, "fonts")

SEC_COLOR = {
    "Intro": (255, 46, 136), "Chorus": (49, 240, 255), "Verse": (139, 92, 246),
    "Interlude": (255, 210, 63), "Post-Chorus": (255, 46, 136), "Outro": (92, 225, 164),
}

def font(name, size):
    return ImageFont.truetype(os.path.join(FONTS, name), size)

def wrap(words, f, maxw):
    """жадно разбивает список слов на строки, возвращая [[word,...],...]"""
    lines, cur, w = [], [], 0.0
    sp = f.getlength(" ")
    for word in words:
        wl = f.getlength(word)
        if cur and w + sp + wl > maxw:
            lines.append(cur); cur, w = [word], wl
        else:
            w += (sp if cur else 0) + wl; cur.append(word)
    if cur:
        lines.append(cur)
    return lines

class Renderer:
    def __init__(self, W, H, style="neon"):
        self.W, self.H, self.style = W, H, style
        self.s = W / 1920.0
        self.bw, self.bh = W // 6, H // 6          # низкое разрешение для фона
        self.f_lg = font("Montserrat-Black.ttf", int(96 * self.s))
        self.f_sm = font("Montserrat-Bold.ttf", int(26 * self.s))
        self.f_xs = font("Montserrat-Medium.ttf", int(22 * self.s))
        # фон: вертикальный градиент (низкое разрешение)
        top, bot = ((18, 5, 30), (5, 3, 10)) if style == "neon" else ((255, 246, 250), (228, 222, 255))
        t = np.linspace(0, 1, self.bh)[:, None, None]
        self.base = Image.fromarray((np.array(top) * (1 - t) + np.array(bot) * t).astype(np.uint8).repeat(self.bw, 1)).convert("RGBA")
        # кэш «зерна»
        rng = np.random.default_rng(3)
        self.grain = [Image.fromarray((128 + rng.normal(0, 26, (self.bh, self.bw, 1)).repeat(3, 2)).clip(0, 255).astype(np.uint8))
                      .resize((W, H), Image.BILINEAR) for _ in range(6)]
        self.line_cache = OrderedDict()
        # частицы (боке)
        rng2 = np.random.default_rng(21)
        n = 30
        self.part = dict(
            x=rng2.random(n), y=rng2.random(n),
            r=rng2.uniform(0.006, 0.030, n),
            sp=rng2.uniform(0.1, 0.45, n),
            ph=rng2.uniform(0, 6.28, n),
            c=rng2.integers(0, 3, n),
        )
        self.beats = np.array(json.load(open(os.path.join(ROOT, "data", "beats.json")))["beats"])
        self.layout()

    # ---------- раскладка строк ----------
    def layout(self):
        """подбирает кегль так, чтобы строка влезала максимум в 2 ряда"""
        self.blocks = []
        self.line_font = {}
        self.line_lh = {}
        maxw = int(self.W * 0.82)
        for i, l in enumerate(LYR["lines"]):
            words = [w["w"] for w in l["words"]]
            size = int(96 * self.s)
            while size > int(58 * self.s):
                f = font("Montserrat-Black.ttf", size)
                if len(wrap(words, f, maxw)) <= 2:
                    break
                size -= 4
            f = font("Montserrat-Black.ttf", size)
            self.line_font[i] = f
            self.line_lh[i] = int(size * 1.17)
            rows = wrap(words, f, maxw)
            lay = []
            for row in rows:
                widths = [f.getlength(x) for x in row]
                sp = f.getlength(" ")
                lay.append((row, widths, sum(widths) + sp * (len(row) - 1)))
            self.blocks.append(lay)

    def line_sprite(self, i):
        """прозрачный слой с текстом строки + свечением (кэш)."""
        if i in self.line_cache:
            self.line_cache.move_to_end(i)
            return self.line_cache[i]
        l = LYR["lines"][i]
        rows = self.blocks[i]
        f_lg = self.line_font[i]
        lh = self.line_lh[i]
        n = len(rows)
        img = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        y0 = self.H // 2 - (n - 1) * lh // 2 - int(10 * self.s)
        boxes = []
        neon = self.style == "neon"
        for ri, (row, widths, tot) in enumerate(rows):
            x = (self.W - tot) / 2
            y = y0 + ri * lh
            for wi, word in enumerate(row):
                boxes.append((wi, x, y, widths[wi]))
                x += widths[wi] + f_lg.getlength(" ")
        txt = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        dt = ImageDraw.Draw(txt)
        for ri, (row, widths, tot) in enumerate(rows):
            x = (self.W - tot) / 2
            y = y0 + ri * lh
            for word in row:
                dt.text((x, y), word, font=f_lg, fill=(255, 255, 255, 255))
                x += f_lg.getlength(word) + f_lg.getlength(" ")
        col = SEC_COLOR.get(l["section"], (255, 255, 255))
        if neon:
            glow = txt.filter(ImageFilter.GaussianBlur(16 * self.s))
            tint = Image.new("RGBA", (self.W, self.H), col + (0,))
            tint.putalpha(glow.split()[3].point(lambda v: int(v * 0.55)))
            img.alpha_composite(tint)
            wide = txt.filter(ImageFilter.GaussianBlur(46 * self.s)).split()[3].point(lambda v: int(v * 0.35))
            hal = Image.new("RGBA", (self.W, self.H), col + (0,))
            hal.putalpha(wide)
            img.alpha_composite(hal)
            img.alpha_composite(txt)
        else:
            dd = ImageDraw.Draw(img)
            for ri, (row, widths, tot) in enumerate(rows):
                x = (self.W - tot) / 2
                y = y0 + ri * lh
                for word in row:
                    dd.text((x, y), word, font=f_lg, fill=(52, 32, 74, 255))
                    x += f_lg.getlength(word) + f_lg.getlength(" ")
        self.line_cache[i] = (img, boxes)
        while len(self.line_cache) > 4:
            self.line_cache.popitem(last=False)
        return self.line_cache[i]

    # ---------- кадр ----------
    def frame(self, t, out_img=None):
        W, H, s = self.W, self.H, self.s
        fi = min(len(ENER["rms"]) - 1, max(0, int(t * ENER["fps"])))
        rms = ENER["rms"][fi]; low = ENER["low"][fi]; high = ENER["high"][fi]
        sec = LYR["sections"][0]
        for sn in LYR["sections"]:
            if sn["start"] <= t < sn["end"]:
                sec = sn
        col = SEC_COLOR.get(sec["name"], (255, 255, 255))
        neon = self.style == "neon"
        bw, bh = self.bw, self.bh
        acc = np.zeros((bh, bw, 3), dtype=np.float32)
        yy, xx = np.mgrid[0:bh, 0:bw].astype(np.float32)
        specs = [((0.22, 0.30), 1.25, 0.95, 0.31, (255, 46, 136), 1.15),
                 ((0.80, 0.70), 1.10, 1.25, 0.23, (49, 240, 255), 1.00),
                 ((0.52, 0.85), 1.45, 0.75, 0.17, (139, 92, 246), 0.95)]
        for (cx, cy), rx, ry, spd, c, k in specs:
            x = (cx + 0.15 * math.sin(t * spd + cx * 9)) * bw
            y = (cy + 0.13 * math.cos(t * spd * 1.27 + cy * 7)) * bh
            r = (0.30 + 0.13 * low + 0.10 * rms) * bw * rx
            r2 = r * ry
            g = np.exp(-(((xx - x) / r) ** 2 + ((yy - y) / r2) ** 2) * 2.8)
            g *= (0.30 + 0.55 * rms) * k
            acc += g[..., None] * np.array(c, dtype=np.float32) / 255.0
        # частицы-боке
        cc = [np.array((255, 190, 230), np.float32), np.array((170, 240, 255), np.float32),
              np.array((210, 190, 255), np.float32)]
        for k in range(len(self.part["x"])):
            px = (self.part["x"][k] + 0.045 * math.sin(t * self.part["sp"][k] * 2.2 + self.part["ph"][k])) * bw
            py = (self.part["y"][k] - 0.030 * t * self.part["sp"][k] * 0.25) % 1.0 * bh
            pr = self.part["r"][k] * bw * (1.0 + 0.5 * high)
            g = np.exp(-(((xx - px) / pr) ** 2 + ((yy - py) / pr) ** 2) * 2.2)
            acc += g[..., None] * cc[self.part["c"][k]] / 255.0 * 0.34
        # пульс по битам
        bi = np.searchsorted(self.beats, t) - 1
        pulse = math.exp(-(t - self.beats[bi]) * 5.5) if 0 <= bi < len(self.beats) else 0.0
        base = np.asarray(self.base.convert("RGB"), dtype=np.float32) / 255.0
        m = (0.85 + 0.9 * np.clip(low, 0, 1)) if neon else 0.9
        arr = base * (m * (0.92 + 0.32 * pulse) if neon else 1.0) + acc * ((0.50 + 0.30 * pulse) if neon else 0.30)
        # виньетка
        vk = 0.55 if neon else 0.16
        vg = 1.0 - vk * (((xx - bw / 2) / (bw / 2)) ** 2 + ((yy - bh / 2) / (bh / 2)) ** 2) / 2
        arr = arr * np.clip(vg, 0.25, 1.0)[..., None]
        # затемнение в зоне текста для контраста
        scrim = 1.0 - (0.42 if neon else 0.0) * np.exp(-(((yy - bh / 2) / (bh * 0.42)) ** 2))
        arr = arr * scrim[..., None]
        arr = np.clip(arr, 0, 1) ** (1 / 1.05)
        img = Image.fromarray((arr * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR).convert("RGBA")
        # текущая строка
        li = -1
        for i, l in enumerate(LYR["lines"]):
            if l["start"] <= t < l["end"]:
                li = i; break
        if li >= 0:
            sprite, boxes = self.line_sprite(li)
            l = LYR["lines"][li]
            local = t - l["start"]
            k = min(1.0, local / 0.28)
            ease = 1 - (1 - k) ** 3
            alpha = int(255 * ease)
            dy = int((1 - ease) * 30 * s)
            sp = sprite
            if k < 1.0:                      # лёгкий «наезд» при появлении
                sc = 1.0 + 0.06 * (1 - ease)
                nw, nh = int(self.W * sc), int(self.H * sc)
                sp = sp.resize((nw, nh), Image.BILINEAR)
                sp, dy = sp, dy - int((nh - self.H) / 2)
            if alpha < 255 or dy:
                sp = sp.copy()
                a = sp.split()[3].point(lambda v: int(v * alpha / 255))
                sp.putalpha(a)
            img.alpha_composite(sp, (0, dy))
            # подсветка текущего слова
            words = l["words"]
            act = -1
            for wi, w in enumerate(words):
                if w["start"] <= t < w["end"]:
                    act = wi; break
            if act >= 0 and act < len(boxes):
                d2 = ImageDraw.Draw(img)
                wi, x, y, wd = boxes[act]
                # слово в акцентном цвете + подчёркивание
                word = words[act]["w"]
                yy = y + dy
                if neon:
                    f_act = self.line_font[li]
                    d2.text((x, yy), word, font=f_act, fill=col + (255,))
                    uy = yy + int(self.line_lh[li] * 0.92)
                    d2.line([x, uy, x + wd, uy], fill=col + (230,), width=max(2, int(5 * s)))
                else:
                    d2.text((x, yy), word, font=self.line_font[li], fill=(226, 22, 120, 255))
            # следующая строка
            if li + 1 < len(LYR["lines"]):
                nxt = LYR["lines"][li + 1]["text"]
                if self.f_xs.getlength(nxt) < W * 0.8:
                    d2 = ImageDraw.Draw(img)
                    d2.text((W // 2, int(H * 0.72)), nxt, font=self.f_xs,
                            fill=(255, 255, 255, int(70 + 40 * high)) if neon else (90, 70, 120, 140), anchor="mm")
        # вспышка на входе в секцию
        pl = t - sec["start"]
        if 0 <= pl < 0.5:
            fa = int(150 * max(0.0, 1 - pl / 0.5) ** 2)
            fl = Image.new("RGBA", (W, H), col + (fa,))
            img.alpha_composite(fl.filter(ImageFilter.GaussianBlur(30 * s)))
        # хедер
        d = ImageDraw.Draw(img)
        head_c = (255, 255, 255, 210) if neon else (40, 25, 55, 220)
        d.text((int(72 * s), int(60 * s)), "D.T.A.M.", font=self.f_sm, fill=head_c)
        d.text((W - int(72 * s), int(64 * s)), "BRITNEY MANSON", font=self.f_xs,
               fill=(200, 190, 220, 170) if neon else (110, 95, 130, 200), anchor="ra")
        # метка секции
        d.text((W // 2, H - int(96 * s)), sec["name"].upper(), font=self.f_sm,
               fill=col + (215,), anchor="mm")
        # прогресс-бар
        py = H - int(38 * s)
        d.line([int(72 * s), py, W - int(72 * s), py], fill=(255, 255, 255, 40) if neon else (0, 0, 0, 40),
               width=max(2, int(4 * s)))
        pr = t / LYR["duration"]
        d.line([int(72 * s), py, int(72 * s + (W - 144 * s) * pr), py], fill=col + (235,), width=max(2, int(4 * s)))
        # зерно
        g = self.grain[int(t * 12) % len(self.grain)]
        img = Image.blend(img.convert("RGB"), g, 0.05)
        return img

def ensure_wav():
    """wav для рендера не храним (26 МБ) — собираем из flac/mp3 при первом запуске."""
    wav = os.path.join(ROOT, "audio", "D.T.A.M.wav")
    if os.path.exists(wav):
        return wav
    flac = os.path.join(os.path.dirname(ROOT), "muz", "Britney Manson - D.T.A.M (Explicit).flac")
    src = flac if os.path.exists(flac) else os.path.join(ROOT, "audio", "D.T.A.M.mp3")
    subprocess.run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", src,
                    "-map", "0:a", "-c:a", "pcm_s16le", "-ar", "44100", wav], check=True)
    return wav


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=LYR["duration"])
    ap.add_argument("--out", default=os.path.join(D, "clips/clip.mp4"))
    ap.add_argument("--style", default="neon", choices=["neon", "soft"])
    ap.add_argument("--w", type=int, default=1920)
    ap.add_argument("--h", type=int, default=1080)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--crf", type=int, default=20)
    ap.add_argument("--preset", default="veryfast")
    ap.add_argument("--threads", type=int, default=2)
    a = ap.parse_args()

    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    r = Renderer(a.w, a.h, a.style)
    n = int((a.end - a.start) * a.fps)
    cmd = [FFMPEG, "-hide_banner", "-loglevel", "error", "-y",
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{a.w}x{a.h}", "-r", str(a.fps), "-i", "-",
           "-ss", str(a.start), "-t", str(a.end - a.start),
           "-i", ensure_wav(),
           "-map", "0:v", "-map", "1:a",
           "-c:v", "libx264", "-preset", a.preset, "-crf", str(a.crf), "-threads", str(a.threads),
           "-x264-params", "rc-lookahead=10:bframes=2:ref=2", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", a.out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(n):
        t = a.start + i / a.fps
        p.stdin.write(r.frame(t).tobytes())
        if i % 60 == 0:
            print(f"\r{i}/{n} кадров  t={t:6.1f}s", end="", file=sys.stderr, flush=True)
    p.stdin.close(); p.wait()
    print(f"\nготово: {a.out}", file=sys.stderr)

if __name__ == "__main__":
    main()
