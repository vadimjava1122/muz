#!/usr/bin/env bash
# Полный прогон одного клипа. Меняй только переменные сверху.
set -e
SRC="/tmp/w/src.mp4"          # присланный файл
START=0                       # окно заказа
DUR=56.45
SLUG="notime"
TRACK="NO_TIME"
PROJ="projects/notime.json"

pip install -q -r docs/requirements.txt
FF=$(python3 -c "import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())")

# 1. материал
$FF -hide_banner -i "$SRC" 2>&1 | grep -E "Duration|Stream"

# 2. звук клипа
$FF -y -ss $START -t $DUR -i "$SRC" -vn -c:a libmp3lame -b:a 192k "audio/$TRACK.mp3"

# 3. тайминги/лирика -> lyrics/$SLUG/lyrics_*.json   (правится таблица в build.py)
python3 "lyrics/$SLUG/build.py"

# 4. анализ музыки (BPM, RMS, биты)
cd video && python3 analyze.py --audio "../audio/$TRACK.mp3" --out "../data/$SLUG"

# 5. тестовый кусок -> глазами
python3 render3.py --project "../$PROJ" --start 20 --end 30 --out /tmp/test.mp4 --crf 22
echo "смотри /tmp/test.mp4: текст, края, эффекты"

# 6. полный мастер
python3 render3.py --project "../$PROJ" --start $START --end $DUR --out /tmp/master.mp4 --crf 21

# 7. финальное сжатие
$FF -y -i /tmp/master.mp4 -c:v libx264 -preset slow -crf 26 -threads 2 \
   -x264-params rc-lookahead=10:bframes=3:ref=3 -pix_fmt yuv420p \
   -c:a aac -b:a 192k -movflags +faststart "clips/${SLUG}_1080p.mp4"

# 8. контроль
$FF -hide_banner -i "clips/${SLUG}_1080p.mp4" 2>&1 | grep -E "Duration|Stream"
ls -lh "clips/${SLUG}_1080p.mp4"
